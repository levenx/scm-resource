module.exports = {
  apps: [
    {
      name: 'build-material-console',
      script: 'npm run serve',

      // Options reference: https://pm2.keymetrics.io/docs/usage/application-declaration/
      args: 'one two',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      env: {
        NODE_ENV: 'development',
      },
      env_production: {
        NODE_ENV: 'production',
      },
    },
  ],

  deploy: {
    cms: {
      user: 'root',
      host: '39.108.168.104',
      ssh_options: ['StrictHostKeyChecking=no', 'PasswordAuthentication=yes'],
      ref: 'origin/feature/material',
      repo: 'https://gitee.com/levenx-business/build-material-console.git',
      path: '/apps/build-material-console',
      'post-deploy':
        'npm install && npm run build && pm2 startOrRestart ecosystem.config.js --env production',
    },
  },
};
