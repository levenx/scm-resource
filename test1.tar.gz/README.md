# Material Console 

## 目录说明

- main.tsx 项目入口

- router.ts 项目路由

- config 系统级别配置

- service 接口请求方法

- components 组件目录
    - common 通用组件
    - business 业务组件

- asset 静态资产目录

- pages 路由组件

