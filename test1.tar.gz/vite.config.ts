import { defineConfig, resolveConfig } from 'vite'
import reactRefresh from '@vitejs/plugin-react-refresh'
import vitePluginImp from 'vite-plugin-imp'
import { ViteAliases } from 'vite-aliases'
import reactSvgPlugin from 'vite-plugin-react-svg';
import typescript from '@rollup/plugin-typescript';

// https://vitejs.dev/config/
export default defineConfig({
  define: {
    BUILD_TIME: JSON.stringify(new Date().toLocaleString()),
    IS_PROD: process.env.NODE_ENV === 'production'
  },
  server: {
    port: 8833,
    strictPort: true,
  },
  plugins: [
    reactRefresh(),
    reactSvgPlugin(),
    ViteAliases({
      dir: 'src',
      prefix: "@/",
      deep: true,
      root: process.cwd()
    }),
    vitePluginImp({
      libList: [
        {
          libName: "antd",
          style: (name) => `antd/lib/${name}/style/index.less`,
        },
      ],
    })],
  css: {
    preprocessorOptions: {
      less: {
        // 支持内联 JavaScript
        javascriptEnabled: true,
      }
    }
  }
})
