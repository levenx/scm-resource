import React from 'react';

import './index.less';

export default function DomainManage() {
    return (
        <div>
            DomainManage
        </div>
    )
}
