import React, { useState, useEffect } from 'react';
import { Modal, message } from 'antd';
import { Image, UploadModal } from '@/components';
import { HomeBannerField } from '@/service/config/home_banner';
import { createConfig } from '@/service/config/home_banner';
import './index.less';

interface WebsiteBannerEditProps {
    dataSource: Array<HomeBannerField>;
    visible: boolean;
    onClose: (status?: boolean) => void;
}

export default function WebsiteBannerEdit(props: WebsiteBannerEditProps) {
    const { visible, onClose, dataSource } = props;

    const [banner, setBanner] = useState<Array<HomeBannerField>>([]);

    useEffect(() => {
        if (visible) {
            setBanner(dataSource.map((data, index) => ({ ...data, id: index + 1 })));
        }
    }, [dataSource, visible])

    const onRemove = (id?: number) => {
        if (!id) return;
        const index = banner.findIndex(ban => ban.id === id);
        banner.splice(index, 1);
        setBanner([...banner]);
    }

    return (
        <Modal
            visible={visible}
            onCancel={() => onClose()} width="1000px"
            title="广告设置"
            closable={false}
            okText="保存"
            cancelText="取消"
            onOk={() => Modal.confirm({
                title: "确认保存广告配置吗?",
                icon: null,
                okText: '确认',
                cancelText: "取消",
                onOk: async () => {
                    let result = await createConfig({ identify: 'home_banner', content: JSON.stringify(banner) });
                    if (result.code === 0) {
                        message.success('保存成功');
                        onClose(true);
                    }
                }
            })}
        >
            <div className="website-banner-edit">
                {
                    banner?.map((ban) => {
                        return <div key={ban.id} className="website-banner-edit__item">
                            <Image src={ban.image} />
                            <div className="website-banner__operate">
                                <span className="banner-delete" onClick={() => onRemove(ban.id)} >删除</span>
                            </div>
                        </div>
                    })
                }
                <UploadModal value={''} onChange={() => { }} />
            </div>
        </Modal>
    )
}
