import React, { useState } from 'react';
import { Carousel, Modal } from 'antd';
import { Image } from '@/components';
import { useRequest } from '@umijs/hooks';
import { getHomeBanner } from '@/service/config/home_banner';
import WebsiteBannerEdit from './edit';
import './index.less';

export default function WebsiteBanner() {

    const [editVisible, setEditVisible] = useState(false);

    const { data, run } = useRequest(getHomeBanner);

    return (<section className="website-partial">
        <div className="website-partial__title">
            <div className="title">顶部广告</div>
            <div className="edit" onClick={() => setEditVisible(true)}>编辑</div>
        </div>
        <div className="website-banner">
            <Carousel autoplay>
                {
                    data?.data?.map(banner => {
                        return <div className="website-banner__item">
                            <Image src={banner.image} />
                        </div>
                    })
                }
            </Carousel>
        </div>

        <WebsiteBannerEdit
            dataSource={data?.data || []}
            visible={editVisible}
            onClose={(status) => {
                setEditVisible(false);
                if (status) {
                    run();
                }
            }} />
    </section>
    )
}
