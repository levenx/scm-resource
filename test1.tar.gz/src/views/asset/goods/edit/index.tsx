import React, { useEffect } from 'react';
import { Modal, Input, Button, Form, message } from 'antd';
import { RichTextEditor, UploadModal, TextArea } from '@/components';
import { createAssetGoods, updateAssetGoods } from '@/service/admin/asset/product';
import CategoryTree from '@/components/category-tree';
import './index.less';

interface GoodsEditProps {
    visible?: boolean;
    onClose?: (status?: boolean) => void;
    defaultValue?: any;
}

export default function GoodsEdit(props: GoodsEditProps) {
    const { visible, onClose, defaultValue } = props;

    const [form] = Form.useForm();

    useEffect(() => {
        if (visible) {
            form.setFieldsValue(defaultValue);
        }
    }, [defaultValue])

    const onEditClose = (status?: boolean) => {
        onClose?.(status);
        form.resetFields();
    }

    const onSubmit = async () => {
        const values = form.getFieldsValue();
        if (defaultValue?.id) {
            let result = await updateAssetGoods({ ...values, id: defaultValue.id });
            if (result.code === 0) {
                message.success("更新成功");
                onEditClose(true);
            }
        } else {
            let result = await createAssetGoods({ ...values });
            if (result.code === 0) {
                message.success("提交成功");
                onEditClose(true);
            }
        }
        form.resetFields();
    }

    return (
        <Modal
            className="goods-edit"
            centered
            width={1400}
            visible={visible}
            onCancel={() => onEditClose()}
            title={false}
            closable={false}
            footer={false}
        >
            <Form layout="vertical" form={form}>
                <div className="goods-edit-body">
                    <div className="goods-edit-title">
                        <Form.Item name="title" noStyle>
                            <Input />
                        </Form.Item>
                        <Button type="primary" onClick={onSubmit}>发布</Button>
                    </div>
                    <div className="goods-edit-content">
                        <div className="goods-edit-content__left">
                            <Form.Item name="content" noStyle>
                                <RichTextEditor />
                            </Form.Item>
                        </div>
                        <div className="goods-edit-content__right">
                            <Form.Item label="Picture" name="picture" >
                                <UploadModal packetKey="material" column={2} limit={8} style={{ height: 110 }} />
                            </Form.Item>
                            <Form.Item label="Summary" name="description" >
                                <TextArea />
                            </Form.Item>
                            <Form.Item label="Category" name="itemizes" >
                                <CategoryTree />
                            </Form.Item>
                        </div>
                    </div>
                </div>
            </Form>
        </Modal>
    )
}
