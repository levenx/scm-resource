import React, { Fragment, useState } from 'react';
import { Button, Input, Form, Popconfirm } from 'antd';
import classnames from 'classnames';
import { useEffect } from 'react';
import { createCategory, updateCategory } from '@/service/admin/category';
import { delCategory } from '@/service/admin/category/id';

interface CategoryOptionProps {
    isAdd?: boolean;
    id?: number;
    pid?: number;
    title?: string;
    type?: string;
    time?: string;
    fetchList: () => void;
    onClick?: () => void;
    active?: boolean;
}

export default function CategoryOption(props: CategoryOptionProps) {
    const { id, pid, title, type, time, isAdd, fetchList, onClick, active } = props;
    const [modifyStatus, setModifyStatus] = useState(false);
    const [form] = Form.useForm();

    useEffect(() => {
        form.setFieldsValue({ title, type });
    }, [])

    const onSubmit = async () => {
        const values = form.getFieldsValue();
        if (id) {
            let result = await updateCategory({ id, pid, ...values });
        } else {
            let result = await createCategory({ pid, ...values });
        }
        setModifyStatus(false);
        fetchList();
    }

    return (<>
        {
            isAdd ? <div className={classnames("category-content__item-option category-content__item-add", {
                'category-option--active': modifyStatus || isAdd
            })}
                onClick={() => {
                    if (!modifyStatus) {
                        setModifyStatus(true)
                    }
                }}
            >
                {
                    !modifyStatus ?
                        <div>添加</div>
                        : <>
                            <div className="option-left">
                                <Form form={form}>
                                    <Form.Item label="标题" name="title">
                                        <Input />
                                    </Form.Item>
                                    <Form.Item label="类型" name="type">
                                        <Input />
                                    </Form.Item>
                                </Form>
                            </div>
                            <div className="option-right">
                                <Button type="link" onClick={onSubmit}>确认</Button>
                                <Button type="link" onClick={() => setModifyStatus(false)}>取消</Button>
                            </div>
                        </>
                }
            </div>
                :
                <div
                    onClick={onClick}
                    className={classnames("category-content__item-option",
                        {
                            'category-option--active': modifyStatus,
                            'category-option--selected': active,
                            'category-add': isAdd && !modifyStatus
                        })}>
                    {
                        <div className="option-left">
                            {
                                !modifyStatus ?
                                    <>
                                        <div className="category-title">{title}</div>
                                        <div className="category-title">{type}</div>
                                        <div className="category-time">{time}</div>
                                    </> :
                                    <Form form={form}>
                                        <Form.Item label="标题" name="title">
                                            <Input />
                                        </Form.Item>
                                        <Form.Item label="类型" name="type">
                                            <Input />
                                        </Form.Item>
                                    </Form>
                            }
                        </div>
                    }
                    <div className="option-right">
                        {
                            !modifyStatus ?
                                <div onClick={event => event.stopPropagation()}>
                                    <Button type="link" onClick={() => setModifyStatus(true)}>编辑</Button>
                                    <Popconfirm
                                        title="确认删除吗？"
                                        okText="删除"
                                        okButtonProps={{ danger: true }}
                                        cancelText="取消"
                                        onConfirm={async () => {
                                            if (!id) return;
                                            let result = await delCategory(id);
                                            if (result.code === 0) {
                                                fetchList();
                                            }
                                        }}>
                                        <Button type="link" danger>删除</Button>
                                    </Popconfirm>
                                </div>
                                :
                                <div onClick={event => event.stopPropagation()}>
                                    <Button type="link" onClick={onSubmit}>确认</Button>
                                    <Button type="link" onClick={() => setModifyStatus(false)}>取消</Button>
                                </div>
                        }
                    </div>
                </div>
        }

    </>
    )
}