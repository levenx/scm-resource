import React, { Fragment, useState } from 'react';
import { Button, Modal, Cascader, Empty, FormInstance } from 'antd';
import { fetchCategory } from '@/service/admin/category';
import useCategory from '@/views/asset/hooks/useCategory';
import { useRequest } from '@umijs/hooks';
import CategoryOption from './option';
import dayjs from 'dayjs';
import './index.less';

interface CategoryField {

}

interface AssetCategoryProps {
    onKeywordChange?: (key: string, value: any) => void;
}

export default function AssetCategory(props: AssetCategoryProps) {

    const { onKeywordChange } = props;

    const [categoryVisible, setCategoryVisible] = useState<CategoryField | null>(null);
    const [currentCategoryId, setCurrentCategoryId] = useState<number>(-1);

    const { data: categorySelect, loadData: loadCategorySelect } = useCategory();

    const { data: category, refresh: refreshCategory } = useRequest(fetchCategory);

    const { data: subCategory, run: loadSubCategory, refresh: refreshSubCategory } = useRequest(fetchCategory, { manual: true });

    const onCategorySelect = (categoryId: number) => {
        loadSubCategory(categoryId, 1, 30);
        setCurrentCategoryId(categoryId);
    }

    return (
        <Fragment>
            <div className="category-select">
                <Cascader
                    options={categorySelect?.data || []}
                    onChange={(value) => {
                        onKeywordChange?.('categoryId', value.pop());
                    }}
                    onDropdownVisibleChange={(visible: boolean) => {
                        if (visible) {
                            loadCategorySelect();
                        }
                    }} />
                <Button type="primary" onClick={() => setCategoryVisible({})}>+</Button>
            </div>

            <Modal visible={Boolean(categoryVisible)}
                centered
                width={800}
                onCancel={() => setCategoryVisible(null)}
                title={false}
                closable={false}
                footer={false}>
                <div className="category-content">
                    <div className="category-content__item">
                        {
                            category ?
                                <div className="category-content__first">
                                    <div className="category-content__list">
                                        {
                                            category.data.map(cate => {
                                                return <CategoryOption
                                                    key={cate.id}
                                                    active={cate.id === currentCategoryId}
                                                    onClick={() => onCategorySelect(cate.id)}
                                                    id={cate.id}
                                                    title={cate.title}
                                                    type={cate.type}
                                                    time={dayjs(cate.createdAt).format("YYYY-MM-DD HH:mm:ss")}
                                                    fetchList={() => refreshCategory()}
                                                />
                                            })
                                        }
                                    </div>
                                    <CategoryOption isAdd={true} fetchList={() => refreshCategory()} />
                                </div>
                                :
                                <Empty />
                        }
                    </div>
                    <div className="category-content__item">
                        {
                            subCategory ?
                                <div className="category-content__second">
                                    <div className="category-content__list">
                                        {
                                            subCategory.data.map(category => {
                                                return <CategoryOption
                                                    key={category.id}
                                                    id={category.id}
                                                    pid={currentCategoryId}
                                                    title={category.title}
                                                    type={category.type}
                                                    time={dayjs(category.createdAt).format("YYYY-MM-DD HH:mm:ss")}
                                                    fetchList={() => refreshSubCategory()}
                                                />
                                            })
                                        }
                                    </div>
                                    <CategoryOption
                                        isAdd={true}
                                        pid={currentCategoryId}
                                        fetchList={() => refreshSubCategory()} />
                                </div>
                                :
                                <Empty />
                        }
                    </div>
                </div>
            </Modal>
        </Fragment>
    )
}
