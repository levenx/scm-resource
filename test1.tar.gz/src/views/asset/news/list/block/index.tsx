import React from 'react';
import { Tag, Switch } from 'antd';
import { DataProps } from '@/components/data-manage';
import { GoodsField } from '@/service/admin/asset/product';
import { updateAssetNews } from '@/service/admin/asset/news';
import { Icon } from '@/components';

import './index.less';


export default function GoodsBlock(props: DataProps<GoodsField>) {
    const { dataSource, loading, refresh, onOpenDetail } = props;
    return (
        <div className="news-block">
            {
                dataSource?.map(data => {
                    const picture = data.picture?.[0];
                    return <div key={data.id} className="news-block__item">
                        <div className="block-head" style={{ backgroundImage: `url(${picture})` }} >
                            <Tag icon={<Icon name="pic" size={18} />} color="#55acee" style={{ padding: '4px 8px', display: 'inline-flex', gap: 4 }}>{data.picture.length}</Tag>
                            {data.status === 1 && <Tag color="#f50" style={{ padding: '4px 8px' }}>已发布</Tag>}
                        </div>

                        <div className="block-content">
                            <div className="block-content__title" title={data.title}>{data.title}</div>
                            <div className="block-content__time">{data.time}</div>
                        </div>

                        <div className="block-foot">
                            <div className="block-foot__left">
                                <Switch checked={Boolean(data.status)} onChange={async (status: boolean) => {
                                    let result = await updateAssetNews({ id: data.id, status: Number(status) });
                                    if (result.code === 0) {
                                        refresh?.();
                                    }
                                }} />
                            </div>
                            <div className="block-foot__right">
                                <Icon name="setting" className="block-func" onClick={() => onOpenDetail?.(data.id)} />
                                <Icon name="reduce" className="block-func" />
                            </div>
                        </div>

                    </div >
                })
            }
        </div >
    )
}
