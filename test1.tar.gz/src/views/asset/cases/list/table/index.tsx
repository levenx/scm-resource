import React from 'react';
import { Table, TableColumnType } from 'antd';
import { DataProps } from '@/components/data-manage';
import { GoodsField } from '@/service/admin/asset/product';
import './index.less';


export default function GoodsTable(props: DataProps<GoodsField>) {
    const { dataSource, loading } = props;

    const columns: TableColumnType<GoodsField>[] = [
        {
            title: 'ID',
            dataIndex: 'id',
            width: 50
        }, {
            title: '标题',
            dataIndex: 'title',
            width: 200
        }, {
            title: '内容',
            dataIndex: 'content',
            width: 400
        }, {
            title: '图片',
            // dataIndex: 'picture',
        },
        {
            title: '状态',
            dataIndex: 'status',
            width: 100
        },
        {
            title: '浏览量',
            dataIndex: 'watch',
            width: 100
        }
    ]

    return (
        <Table
            rowKey="id"
            dataSource={dataSource}
            loading={loading}
            columns={columns}
            pagination={false}
        />
    )
}
