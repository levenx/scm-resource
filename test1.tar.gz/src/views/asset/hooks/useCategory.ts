import React from 'react';
import { useRequest } from '@umijs/hooks';
import { getCategorySelect } from '@/service/admin/category/select';

export default function useCategory(manual: boolean = true) {
    const { data, loading, run: loadData } = useRequest(getCategorySelect, { manual });
    return { data, loadData, loading }
}
