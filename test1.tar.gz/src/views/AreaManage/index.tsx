import React, { useState, useEffect } from 'react';
import { useHistory, useParams } from 'react-router';
import { Table, Drawer, Button, Form, Input, Space } from 'antd';
import { useAntdTable } from '@umijs/hooks';
import { loadAreaData, createAreaData, onlyAreaData } from '@/service/spider';
import dayjs from 'dayjs';
import './index.less';

const getTableData = ({ current, pageSize }: any) =>
    loadAreaData(current, pageSize)
        .then((res: any) => ({
            total: res.total,
            data: res.data,
        }));

export default function AreaManage() {

    const { type, id } = useParams<any>();
    const history = useHistory();

    const [form, setForm] = useState<any>({ id: null });

    useEffect(() => {
        if (!!id) {
            if (id === 'new') {
                setForm({ id: 'new' })
            } else {
                onlyAreaData(id).then(res => {
                    setForm(res.data)
                })
            }
        }
    }, [id])

    const { tableProps, refresh } = useAntdTable(getTableData, {});
    const { pagination, loading, dataSource } = tableProps

    const onAdd = (id: string | number) => {
        history.push(`/spider/area/${id}`)
    }

    const onSubmit = async (values: any) => {
        Object.assign(values, { id });
        let result = await createAreaData(values) as any;
        if (result.code === 0) {
            refresh();
            setForm({});
            history.push(`/spider/area`)
        }
    }

    const onClose = () => {
        history.push(`/spider/area`)
    }

    const columns = [
        {
            title: '标题',
            dataIndex: 'title',
            width: '25%',
            align: 'center'
        },
        {
            title: '缩写',
            dataIndex: 'deputy',
            width: '25%',
            align: 'center'
        },
        {
            title: '配置时间',
            dataIndex: 'createdAt',
            width: '25%',
            align: 'center',
            render: (value: string) => {
                return dayjs(value).format('YYYY-MM-DD HH:mm')
            }
        },
        {
            title: '操作',
            width: '25%',
            align: 'center',
            render: (value: any) => {
                return <Space>
                    <Button type="link" onClick={onAdd.bind(null, value.id)}>编辑</Button>
                    <Button type="link" danger>删除</Button>
                </Space>
            }
        },
    ];

    return (
        <div>
            <div className="area-manage--header">
                <Button type="primary" onClick={onAdd.bind(null, 'new')}>新增</Button>
            </div>
            <Table columns={columns as any}  {...tableProps} />

            <Drawer width={600} visible={!!id} onClose={onClose} title={<div>地区编辑</div>} >
                {
                    !!form?.id && <Form layout="vertical" className="area-form" initialValues={form} onFinish={onSubmit}>
                        <Form.Item label="标签" name="title">
                            <Input />
                        </Form.Item>
                        <Form.Item label="缩写" name="deputy">
                            <Input />
                        </Form.Item>
                        <Button type="primary" size="large" className="area-form--button" htmlType="submit">提交</Button>
                    </Form>
                }
            </Drawer>
        </div>
    )
}
