import React from 'react';
import { Table, TableColumnType, } from 'antd';
import { GoodsField } from '@/service/admin/asset/product';
import { DataProps } from '@/components/data-manage';
import './index.less';

export default function RegionListBlock(props: DataProps<GoodsField>) {

    const { dataSource, loading } = props;

    const columns: TableColumnType<GoodsField>[] = [
        {
            title: 'ID',
            dataIndex: 'id',
            width: 50
        },
        {
            title: '缩写',
            dataIndex: 'deputy',
            width: 100,
            align: 'left'
        },
        {
            title: '标题',
            dataIndex: 'title',
            width: 200,
            align: 'left'
        },
        {
            title: '全称',
            dataIndex: 'fullName',
            align: 'left'
        },
    ]

    return (
        <Table
            rowKey="id"
            dataSource={dataSource}
            loading={loading}
            columns={columns}
            pagination={false}
        />
    )
}
