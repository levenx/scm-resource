import { lazy } from 'react';
import AdminLayout from '@/layout/AdminLayout';

export const routes = [
    {
        path: "/login",
        exact: true,
        component: lazy(() => import('@/pages/Login'))
    },
    {
        path: "/loading",
        exact: true,
        component: lazy(() => import('@/components/common/Loading'))
    },
    {
        component: AdminLayout,
        routes: [
            {
                path: "/",
                exact: true,
                component: lazy(() => import('@/pages/Home'))
            },
            {
                path: '/goods',
                exact: true,
                component: lazy(() => import('@/pages/Asset/goods'))
            },
            {
                path: '/cases',
                exact: true,
                component: lazy(() => import('@/pages/Asset/cases'))
            },
            {
                path: '/news',
                exact: true,
                component: lazy(() => import('@/pages/Asset/news'))
            },
            {
                path: "/asset/:type?/:id?",
                exact: true,
                component: lazy(() => import('@/pages/Asset'))
            },
            {
                path: "/report",
                exact: true,
                component: lazy(() => import('@/pages/Report'))
            },
            {
                path: "/chat",
                exact: true,
                component: lazy(() => import('@/pages/Chat'))
            },
            {
                path: "/setting",
                component: lazy(() => import('@/layout/SettingLayout')),
                routes: [
                    {
                        path: "/setting",
                        exact: true,
                        component: lazy(() => import('@/pages/Setting/Website')),
                    },
                    {
                        path: "/setting/region",
                        exact: true,
                        component: lazy(() => import('@/pages/Setting/area')),
                    },
                    {
                        path: "/setting/report",
                        exact: true,
                        component: lazy(() => import('@/pages/Setting/Report')),
                    }
                ]
            },
        ]
    }
]