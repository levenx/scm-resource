import React from 'react';
import DataManage from '@/components/data-manage';
import { fetchRegions } from '@/service/admin/region/list';
import { getOnlyRegion } from '@/service/admin/region/id';
import RegionTable from '@/views/region/list/table';
import RegionEdit from '@/views/region/edit';
import './index.less';

export default function AreaSetting() {
    return (
        <div className="region">
            <DataManage
                isMode={false}
                title="地区管理"
                fetchList={({ current, pageSize }) => fetchRegions(current, pageSize)}
                fetchOnly={getOnlyRegion}
            >
                <RegionTable />
                <RegionTable />
                <RegionEdit />
            </DataManage>
        </div>
    )
}
