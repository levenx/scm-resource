import React, { useState } from 'react';
import WebsiteBanner from '@/views/setting/website/banner';

import './index.less';

export default function Website() {
    const [edit, setEdit] = useState<string>('');
    return (
        <div className="website">
            <WebsiteBanner />
        </div>
    )
}
