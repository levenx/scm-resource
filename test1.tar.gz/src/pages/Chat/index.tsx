import React, { useState, useEffect } from 'react';
import { Input, Button } from '@arco-design/web-react';
import { useRequest } from '@umijs/hooks';
import useWebSocket from 'react-use-websocket';
import { Image } from '@/components';
import classnames from 'classnames';
import { senCustomerMessage, getChatList } from '@/service/chat';
import './index.less';

export interface IChatMessage {
    avatar: string;
    content: string;
    type?: 'text' | 'image';
    reverso: 0 | 1;
}

export const USER_AVATAR = 'https://cdn.jsdelivr.net/gh/levenx/picture@master/material/bb6427d50ca34eac987eccecc7b140ad.png';

export const CUSTOMER_AVATAR = 'https://cdn.jsdelivr.net/gh/levenx/picture@master/material/9b81f9b958b947a1b99333b749eb3150.jpeg';

export default function Chat() {
    const [content, setContent] = useState('');
    const [messages, setMessages] = useState<IChatMessage[]>([]);
    const [currentUser, setCurrentUser] = useState('');

    const { lastMessage, lastJsonMessage, readyState } = useWebSocket(`ws://api.material.levenx.com:8834`,
        { retryOnError: true, queryParams: { userId: 123321 } });

    const sendMessage = (message: IChatMessage) => {
        setMessages([...messages, message]);
        senCustomerMessage({ userId: currentUser, content })
    }


    const onCustomerReplyText = () => {
        if (!currentUser) return;
        sendMessage({
            avatar: CUSTOMER_AVATAR,
            content: content,
            type: 'text',
            reverso: 1
        })
        setContent('');
    }

    // const senReplyMessage = () => {
    //     if (!currentUser) return;
    //     sendMessage(JSON.stringify({ event: 'chat', data: JSON.stringify({ userId: 123321, content }) }));
    //     senCustomerMessage({ userId: currentUser, content })
    //     setContent("");
    // }

    useEffect(() => {
        if (lastJsonMessage) {
            const { content } = lastJsonMessage;
            setMessages([...messages, { avatar: USER_AVATAR, content, reverso: 0 }])
        }
    }, [lastJsonMessage, setMessages])

    const { data: chats } = useRequest(getChatList);

    return (
        <div className="chat">
            <div className="chat-menu">
                {
                    chats?.data?.map((chat: any) => {
                        return <div className="chat-menu__item" onClick={() => {
                            setCurrentUser(chat);
                        }}>
                            <div className={'chat-item__avatar'}>
                                <Image src={USER_AVATAR} className={'avatar-image'} />
                            </div>
                            {chat}
                        </div>
                    })
                }
            </div>
            <div className="chat-content">
                <div className="chat-content__head">
                    {
                        currentUser && <><div className={'chat-item__avatar'}>
                            <Image src={USER_AVATAR} className={'avatar-image'} />
                        </div>
                            {currentUser}
                        </>
                    }
                </div>
                <div className="chat-content__body">
                    {
                        messages.map((message, inx) => {
                            return <div className={classnames('chat-item', { 'chat-item--right': message.reverso === 1 })}>
                                <div className={'chat-item__avatar'}>
                                    <Image src={message.avatar} className={'avatar-image'} />
                                </div>
                                <div className={classnames('chat-item__content', { 'chat-item__content--image': message.type === 'image' })}>
                                    {message.type === 'image' ? <Image src={content} className={'chat-content__image'} /> : message.content}
                                </div>
                            </div>
                        })
                    }
                </div>
                <div className="chat-content__reply">
                    <Input.TextArea showWordLimit className="reply-text" value={content} onChange={setContent} />
                    <div className="reply-btn">
                        <Button type="primary" size="small" onClick={onCustomerReplyText}>发送</Button>
                    </div>
                </div>
            </div>
        </div >
    )
}
