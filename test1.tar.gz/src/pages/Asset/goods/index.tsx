import React from 'react';
import { DataManage } from '@/components';
import { } from '@/service/asset';
import GoodsBlock from '@/views/asset/goods/list/block';
import GoodsTable from '@/views/asset/goods/list/table';
import GoodsEdit from '@/views/asset/goods/edit';
import AssetCategory from '@/views/asset/category';
import { fetchAssetGoods } from '@/service/admin/asset/product';
import { fetchOnlyGoods } from '@/service/admin/asset/product/id';
import './index.less';

export default function AssetGoods() {

    return (
        <div className="goods">
            <DataManage
                title="商品"
                fetchList={(params) => {
                    const { current, pageSize, categoryId } = params;
                    return fetchAssetGoods(current, pageSize, categoryId)
                }}
                fetchOnly={fetchOnlyGoods}
                extra={<AssetCategory />}
            >
                <GoodsTable />
                <GoodsBlock />
                <GoodsEdit />
            </DataManage>
        </div>
    )
}
