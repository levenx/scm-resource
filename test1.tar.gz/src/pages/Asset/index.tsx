import React, { useState, useRef, useMemo } from 'react';
import { useParams, useHistory } from 'react-router';
import { Button } from 'antd';
import { useToggle } from '@umijs/hooks';
import BaseTable from '@/components/business/BaseTable';
import ProductItemize from '@/components/business/ProductItemize';
import Module from './Module';
import Creative from './Creative';
import { deleteAsset, settingAsset } from '@/service/asset';
import { Column } from '@/components/business/BaseTable/config';
import { moduleMap } from './Module';
import useQuery from '@/hooks/useQuery';
import './index.less';


const configFiles = import.meta.globEager('./config/*.ts');

const config = Object.entries(configFiles).reduce((memo: any, item) => {
    const [path, model] = item;
    const key = path.replace('./config/', '').replace('.ts', '');
    memo[key] = model.default;
    return memo;
}, {});

interface AssetProps {

}

function Asset(props: AssetProps) {
    const { id, type = "news" } = useParams<any>();
    const { itemize } = useQuery();
    const history = useHistory();
    const [creative, setCreative] = useState(() => {
        return id ? {} : null;
    });

    const [module, setModule] = useState(false);
    const [title, setTitle] = useState(() => (moduleMap as any)[type]);
    const { state: isChange, toggle: hasChange } = useToggle(false);
    const tableRef = useRef();

    const loadData = ({ current, pageSize, keyword }: any): any => {
        if (isChange) {
            current = 1;
            hasChange(false);
        }
        return config[type].loadData(current, pageSize).then((res: any) => {
            const { count: total, data } = res;
            return {
                total,
                data,
            }
        })
    }

    const itemizeVisible = useMemo(() => (type === 'goods' && !!itemize), [type, itemize]);

    const onRefresh = () => (tableRef?.current as any)?.refresh?.();


    const columns = [
        { type: Column.Serial },
        {
            title: '标题',
            key: 'title',
            align: 'left'
        },
        {
            title: '图片',
            key: 'picture',
            type: Column.Image
        },
        {
            title: '浏览量',
            key: 'watch',
        },
        {
            key: 'status',
            title: '上线状态',
            type: Column.Status,
            onChange: async (status: boolean, id: number) => {
                await settingAsset({ id, type, status: Number(status) });
                onRefresh();
            },
        },
        {
            title: '创建时间',
            key: 'createdAt',
            type: Column.Time,
        },
        {
            title: "操作",
            type: Column.Tools,
            width: 200,
            tools: [
                {
                    type: Column.Edit,
                    onClick: (item: any) => {
                        history.push(`/asset/${type}/${item.id}`);
                    }
                }, {
                    type: Column.Delete,
                    onClick: (item: any) => {
                        deleteAsset(item.id, type).then(res => onRefresh())
                    }
                }
            ]
        }
    ];


    return (
        <div className="asset-wrap">
            <BaseTable
                ref={tableRef}
                title={title}
                onTitleClick={() => { setModule(true) }}
                onAddClick={() => {
                    history.push(`/asset/${type}/new`);
                    setCreative({});
                }}
                columns={columns}
                loadData={loadData}
                additional={type === 'goods' && <Button type="primary" color="blue" onClick={() => history.push(`${location.pathname}?itemize=new`)}>产品类型</Button>}
            />
            <Creative
                onClose={() => {
                    setCreative(null);
                    onRefresh();
                }} />
            <Module visible={module}
                onClose={(type?: string, title?: string) => {
                    setModule(false);
                    if (title && type) {
                        setTitle(title);
                        history.push(`/asset/${type}`);
                        hasChange(true);
                        setTimeout(() => {
                            onRefresh();
                        }, 0);
                    }
                }} />
            {itemizeVisible && <ProductItemize />}
        </div>
    )
}

export default Asset;