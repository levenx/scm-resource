import React, { useState, useRef, useEffect, useContext, createContext, useMemo } from 'react';
import { useParams, useHistory } from 'react-router-dom';
import { Button, Space } from 'antd';
import { DrawerContext } from '@/components/common/HistoryDrawer/drawerContext';
import HistoryDrawer from '@/components/common/HistoryDrawer';
// import ArticleEditor from '@/components/business/ArticleEditor';
import RichTextEditor from '@/components/rich-text-editor';
import ArticleTitle from '@/components/business/ArticleTitle';
import { UploadModal } from '@/components';
import TextArea from '@/components/common/TextArea';
import ItemizePicker from '@/components/business/ItemizePicker';
import { trimMarkdown } from '@/utils/trim';
import { createAsset, onlyAsset } from '@/service/asset';
import { useRequest } from '@umijs/hooks';
import './creative.less';

const FormContext = createContext({});

interface CreativeForm {
    id?: string | number;
    title?: string;
    content?: string;
}
interface CreativeProps {
    onClose?: () => void;
}

function CreativeCommon(props: any) {
    const { children } = props;
    const { type } = useParams<any>();
    const { value, onChange, onClose, steps } = useContext<any>(FormContext);
    const { current, onNext, onBack, onRest } = useContext<any>(DrawerContext);

    const onSubmit = async () => {
        const params = Object.assign({}, value, { type, picture: value.picture?.join(';') });
        let result = await createAsset(params) as any;
        if (result.code === 0) {
            onClose();
            onRest?.();
        }
    }

    const stepLength = steps?.length - 1;

    const Extra = () => {
        return <Space>
            {current > 0 && <Button type="default" onClick={onBack}>回退</Button>}
            {current < stepLength && <Button type="primary" onClick={() => {
                onNext();
                onChange(Object.assign({}, value, { description: trimMarkdown(value.content).substring(0, 200) }))
            }}>下一步</Button>
            }
            {
                current === stepLength && <Button type="primary" onClick={() => {
                    onSubmit()
                }}>
                    发布
                </Button>
            }
        </Space>
    }

    return <>
        <ArticleTitle
            value={value.title}
            onChange={(title) => {
                onChange(Object.assign({}, value, { title: title }))
            }}
            extra={<Extra />} />

        {children}
    </>
}

function CreativeContent() {
    const { value, onChange } = useContext<any>(FormContext);

    return <RichTextEditor className="creative-content" value={value.content} onChange={(content) => {
        onChange(Object.assign({}, value, { content: content }))
    }} />
}

const CreativeExtra = (props: any) => {
    const { value, onChange } = useContext<any>(FormContext);
    return <div className="creative-extra">
        <UploadModal<string[]>
            packetKey="material"
            limit={9}
            value={value.picture}
            onChange={(picture: Array<string>) => onChange(Object.assign({}, value, { picture }))} />
        <TextArea
            value={value.description}
            onChange={(description: string) => onChange(Object.assign({}, value, { description }))} />
        <div>

        </div>
    </div>
}

const CreativeItemize = () => {
    const { value, onChange } = useContext<any>(FormContext);
    return <div>
        <ItemizePicker value={value.itemizes} onChange={(itemizes: any) => onChange(Object.assign({}, value, { itemizes }))} />
    </div>
}


export default function Creative(props: CreativeProps) {
    const { onClose } = props;
    const history = useHistory();
    const { type, id } = useParams<{ type: string; id: string }>();
    const initValue = { title: '', content: '', itemizes: [], type, id };
    const [value, onChange] = useState<CreativeForm>(initValue);

    const { run, loading, data, error } = useRequest<any>(onlyAsset, { manual: true })
    const steps = useMemo(() => {
        const steps = [{ title: "内容编辑" }, { title: "额外属性" }];
        const itemize = { title: '类型' };

        if (type === 'goods') {
            steps.push(itemize);
        }
        return steps;
    }, [type])

    useEffect(() => {
        if (id && id !== 'new') {
            run(id, type);
        } else {
            onChange(initValue);
        }
    }, [id])


    useEffect(() => {
        if (data?.code === 0) {
            const target = Object.assign({}, value, data?.data);
            if (type === 'goods') {
                Object.assign(target, { itemizes: data?.data?.itemizes.map((v: any) => v.id) })
            }
            Object.assign(target, { picture: data?.data?.picture?.split(';') })
            onChange(target)
        }
    }, [data])

    const onCustomClose = () => {
        history.push(`/asset/${type}`);
        onChange(initValue);
        onClose?.();
    }

    return (
        <FormContext.Provider value={{ value, onChange, onClose: onCustomClose, loading, steps }}>
            <HistoryDrawer
                visible={!!id}
                onClose={onCustomClose}
                steps={steps}>
                <CreativeCommon>
                    <CreativeContent />
                </CreativeCommon>
                <CreativeCommon>
                    <CreativeExtra />
                </CreativeCommon>
                <CreativeCommon>
                    <CreativeItemize />
                </CreativeCommon>
            </HistoryDrawer>
        </FormContext.Provider>
    )
}
