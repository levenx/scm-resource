import React from 'react';
import { DataManage } from '@/components';
import { } from '@/service/asset';
import CasesBlock from '@/views/asset/cases/list/block';
import CasesTable from '@/views/asset/cases/list/table';
import CasesEdit from '@/views/asset/cases/edit';
import { fetchAssetCases } from '@/service/admin/asset/cases';
import { fetchOnlyCase } from '@/service/admin/asset/cases/id';
import './index.less';

export default function AssetGoods() {

    return (
        <div className="goods">
            <DataManage
                title="经典案例"
                fetchList={({ current, pageSize }) => fetchAssetCases(current, pageSize)}
                fetchOnly={fetchOnlyCase}
            >
                <CasesTable />
                <CasesBlock />
                <CasesEdit />
            </DataManage>
        </div>
    )
}
