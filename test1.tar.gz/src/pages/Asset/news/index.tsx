import React from 'react';
import { DataManage } from '@/components';
import { } from '@/service/asset';
import NewsBlock from '@/views/asset/news/list/block';
import NewsTable from '@/views/asset/news/list/table';
import NewsEdit from '@/views/asset/news/edit';
import { fetchAssetNews } from '@/service/admin/asset/news';
import { fetchOnlyNews } from '@/service/admin/asset/news/id';
import './index.less';

export default function AssetGoods() {

    return (
        <div className="goods">
            <DataManage
                title="新闻咨询"
                fetchList={({ current, pageSize }) => fetchAssetNews(current, pageSize)}
                fetchOnly={fetchOnlyNews}
            >
                <NewsTable />
                <NewsBlock />
                <NewsEdit />
            </DataManage>
        </div>
    )
}
