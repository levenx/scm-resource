import React, { useState } from 'react'
import { useHistory, useParams } from 'react-router';
import classnames from 'classnames';
import Modal from '@/components/common/Modal'

interface ModuleProps {
    visible: boolean;
    onClose?: (type?: string, title?: string) => void;
}

export const moduleMap = {
    news: '新闻',
    cases: '案例',
    goods: '商品',
    ads: '广告'
}

export default function Module(props: ModuleProps) {
    const { visible, onClose } = props;
    const { type: curType = 'news' } = useParams<any>();
    const history = useHistory();

    const onChange = (type: string, title: string) => {
        history.push(`/asset/${type}`);
        onClose?.(type, title);
    }

    return (
        <Modal visible={visible} onCancel={onClose}>
            <div className="asset-module">
                {
                    Object.entries(moduleMap).map(module => {
                        const [type, title] = module;
                        return <div
                            key={type}
                            className={classnames("asset-module__item", { "asset-module__item--active": type === curType })}
                            onClick={onChange.bind(null, type, title)}>
                            {title}
                        </div>
                    })
                }
            </div>
        </Modal>
    )
}
