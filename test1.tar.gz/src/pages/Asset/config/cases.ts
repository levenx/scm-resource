import { loadAssetCases } from '@/service/asset';
export default {
    loadData: loadAssetCases
}