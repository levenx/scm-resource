import { loadAssetNews } from '@/service/asset';
export default {
    loadData: loadAssetNews
}