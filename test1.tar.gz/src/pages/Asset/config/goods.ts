import { loadAssetGoods } from '@/service/asset';
export default {
    loadData: loadAssetGoods
}