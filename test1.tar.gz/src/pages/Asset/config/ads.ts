import { loadAssetAds } from '@/service/asset';
export default {
    loadData: loadAssetAds
}