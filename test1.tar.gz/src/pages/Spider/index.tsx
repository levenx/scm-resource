import React, { useEffect } from 'react';
import { useParams, useHistory } from 'react-router';
import SpiderMenu from '@/components/business/SpiderMenu';
import AreaManage from '@/views/AreaManage';
import DomainManage from '@/views/DomainManage';
import LinkManage from '@/views/LinkManage';
import { Menu } from '@/types/index';

import './index.less';

const menus: Array<Menu> = [
    { path: '/spider/domain', title: '网站管理' },
    { path: '/spider/area', title: '地址管理' },
    { path: '/spider/link', title: '上报管理' }]

interface SpiderProps {

}

export default function Spider(props: SpiderProps) {
    const { type } = useParams<{ type: string }>();
    const history = useHistory();

    useEffect(() => {
        if (!type) {
            history.push('/spider/domain')
        }
    }, [type])

    const renderComponent = (type: string) => {
        switch (type) {
            case 'domain':
                return <DomainManage />
            case 'area':
                return <AreaManage />
            case 'link':
                return <LinkManage />
        }
    }

    return (
        <div className="spider">
            <div className="spider-left">
                <SpiderMenu menus={menus} />
            </div>
            <div className="spider-right">
                {
                    renderComponent(type)
                }
            </div>
        </div>
    )
}
