import React from 'react';
import { Layout, } from 'antd'
import ServiceBox from '../../components/common/ServiceBox';
import './index.less';
import { LineChart, DonutChart } from 'bizcharts'
import Donut from '@/components/charts/Donut';
import Doubleaxes from '@/components/charts/Doubleaxes';

const { Sider, Header, Content, Footer } = Layout;

function Home() {
    return (<>
        <div className="main-content__fisrt">
            <div className="main-content__fisrt--left">
                <section className="main-content--access">
                    {
                        [1, 1, 1, 1].map(item => {
                            return <ServiceBox />
                        })
                    }
                </section>
                <section className="main-content--chart">
                    <Doubleaxes />
                </section>
            </div>
            <section className="main-content__fisrt--right">

            </section>
        </div>
        <section className="main-content__second">
            <div className="card">
                <Donut />
            </div>
            <div className="card">
                <Doubleaxes />
            </div>
            <div className="card">

            </div>
        </section>
    </>
    )
}

export default (Home);