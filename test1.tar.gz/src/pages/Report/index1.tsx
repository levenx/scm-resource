import React, { useRef } from 'react';
import { useHistory } from 'react-router-dom';
import BaseTable from '@/components/business/BaseTable';
import { loadReports } from '@/service/report';
import { Column } from '@/components/business/BaseTable/config';
import './index.less';

export default function Region() {
    const history = useHistory();
    const tableRef = useRef();

    const loadData = ({ current, pageSize, keyword }: any): any => {
        return loadReports(current, pageSize).then((res: any) => {
            const { count: total, data: list } = res;
            return {
                total,
                list,
            }
        })
    }

    const onRefresh = () => (tableRef?.current as any)?.refresh?.();

    const columns = [
        { type: Column.Serial },
        {
            title: 'Path',
            key: 'path',
        },
        {
            title: 'method',
            key: 'method',
        },
        {
            title: 'time',
            key: 'time',
        },
        {
            title: 'ip',
            key: 'ip',
        },
        {
            title: 'browser',
            key: 'browser',
            render: (browser: any) => {
                return JSON.stringify(browser);
            }
        },
        {
            title: 'platform',
            key: 'platform',
            render: (platform: any) => {
                return JSON.stringify(platform);
            }
        },
        {
            title: '创建时间',
            key: 'createdAt',
            type: Column.Time,
        },
        // {
        //     title: "操作",
        //     type: Column.Tools,
        //     width: 200,
        //     tools: [
        //         {
        //             type: Column.Edit,
        //             onClick: (item: any) => {
        //                 history.push(`/setting/region/${item.id}`)
        //             }
        //         }, {
        //             type: Column.Delete,
        //             onClick: (item: any) => { }
        //         }
        //     ]
        // }
    ];

    return (
        <div>
            {/* <Table columns={columns} dataSource={data} rowClassName="table-row" /> */}
            <BaseTable
                ref={tableRef}
                title="地区设置"
                onAddClick={() => {
                    history.push(`/setting/region/new`);
                }}
                columns={columns}
                loadData={loadData}
                pageSize={20}
            />
        </div>
    )
}
