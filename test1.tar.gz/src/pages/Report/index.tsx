import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { loadReports } from '@/service/report';
import classnames from 'classnames';
import dayjs from 'dayjs';
import Icon from '@/components/Icon';
import './index.less';


const loadData = ({ current, pageSize, keyword }: any): Promise<any> => {
    return loadReports(current, pageSize).then((res: any) => {
        const { count: total, data: list } = res;
        return {
            total,
            list,
        }
    })
}

export default function Report() {

    const [logs, setLogs] = useState<Array<any>>([]);
    const [currentLog, setCurrentLog] = useState<any>({});

    useEffect(() => {
        loadData({ current: 1, pageSize: 20 }).then(res => {
            const logs = res.list;
            setLogs(logs);
            setCurrentLog(logs[0])
        })
    }, [])

    return (
        <div className="report">
            <div className="report-left">
                {
                    logs.map(log => {
                        return <div className="report-log" onClick={setCurrentLog.bind(null, log)}>
                            <div className="report-log--icon">
                                <Icon name={log.type === 'ajax' ? "rizhi" : 'liulanjilu'} size={18} color="#666" />
                            </div>
                            <div className={classnames("report-log--content", { 'log-content--selected': currentLog.id === log.id })}>
                                <div className="log-header">
                                    <span className="method">{log.method}</span>
                                    <span className="path">{log.path}</span>
                                </div>
                                <div className='log-content'></div>
                                <div className="log-footer">
                                    {log.time && <span className="cost">{log.time}ms</span>}
                                    <span className="time">{dayjs(log.createdAt).format("YYYY-MM-DD HH:mm:ss")}</span>
                                </div>
                            </div>
                        </div>
                    })
                }
            </div>
            <div className="report-right">
                <div></div>

                <div className="report-table">
                    <div className="row">
                        <div className="col">path</div>
                        <div className="col">{currentLog.path}</div>
                    </div>
                    <div className="row">
                        <div className="col">耗时</div>
                        <div className="col">{currentLog.time}</div>
                    </div>
                    <div className="row">
                        <div className="col">userAgent</div>
                        <div className="col">{currentLog.userAgent}</div>
                    </div>
                    <div className="row">
                        <div className="col">IP</div>
                        <a href={`https://www.ip138.com/iplookup.asp?ip=${currentLog.ip}&action=2`} target="_blank" className="col">{currentLog.ip}</a>
                    </div>
                    <div className="row">
                        <div className="col">browser</div>
                        <div className="col">{currentLog.browser?.name} | {currentLog.browser?.version} | {currentLog.browser?.major}</div>
                    </div>
                    <div className="row">
                        <div className="col">os</div>
                        <div className="col">{currentLog.platform?.os?.name} ({currentLog.platform?.os?.version})</div>
                    </div>
                    <div className="row">
                        <div className="col">device</div>
                        <div className="col">{currentLog.platform?.device?.model} ({currentLog.platform?.device?.type})</div>
                    </div>
                    <div className="row">
                        <div className="col">device.vendor</div>
                        <div className="col">{currentLog.platform?.device?.vendor}</div>
                    </div>
                </div>
            </div>
        </div>
    )
}
