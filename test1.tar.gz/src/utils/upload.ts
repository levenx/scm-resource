import React, { useState, useEffect, useRef } from 'react';
import { useToggle } from '@umijs/hooks';
import qiniujs from 'qiniu-js';
import qiniu from 'qiniu';

const initToken = () => {
    const accessKey = 'B_4zonc-5muZd9dijUnUKrdxvBJ0-hdUYz5fWU8p';
    const secretKey = '2KCylaRx1S8PTEzAZKHb3nSz9daU8yTGY18iUIa3';
    const mac = new qiniu.auth.digest.Mac(accessKey, secretKey);
    var options = { scope: "levenx-world" };
    var putPolicy = new qiniu.rs.PutPolicy(options);
    return putPolicy.uploadToken(mac);
}

const qiniuUpload = (file: File, cb: () => void) => {

    const [token, setToken] = useState(() => initToken());
    const [data, setData] = useState();
    const [error, setError] = useState();
    const [process, setProcess] = useState();

    const { state: loading, toggle } = useToggle();
    let cancel = null;


    useEffect(() => { }, [

    ])

    const key = `${new Date().getFullYear()}${new Date().getMonth()}${new Date().getDate()}${Math.random().toString(36).slice(-8)}`;

    const observer = {
        next(res: any) {
            console.log('res:', res)
        },
        error(err: any) {
            console.log("err:", err)
        },
        complete(res: any) {
            console.log("success:", res);
        }
    }


    const upload = () => {
        const observable = qiniujs.upload(file, key, token);
        const subscription = observable.subscribe(observer);
        cancel = subscription.unsubscribe;
    }

    return {
        upload,
        cancel,
        loading,
        data,
        error,
        process
    }
}