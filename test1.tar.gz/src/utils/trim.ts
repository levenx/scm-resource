import marked from 'marked';
// 提取 html 文字
export function trimHtml(str: string = ''): string {
    if (!str) {
        return ''
    }
    str = str.replace(/(\n)/g, '');
    str = str.replace(/(\t)/g, '');
    str = str.replace(/(\r)/g, '');
    str = str.replace(/<\/?[^>]*>/g, '');
    str = str.replace(/\s*/g, '');
    str = str.replace(/<[^>]*>/g, '');
    str = str.replaceAll('s&gt;', '');
    str = str.replaceAll('amp;', '');
    str = str.replaceAll('&quot;', '\'');
    str = str.replaceAll('&lt;', '');
    str = str.replaceAll('&gt;', '');
    return str;
}

export function trimMarkdown(str: string = "") {
    if (!str) {
        return "";
    }
    str = marked(str);
    return trimHtml(str);
}