import dayjs from 'dayjs';

export const format = (time: string, format: string = "YYYY-MM-DD hh:mm") => {
    return dayjs(time).format(format)
}