import React, { useState, useEffect, useMemo } from 'react';
import { createPortal } from 'react-dom';
import Hub from './hub';
import { Icon } from 'dumbooo';
import Image from '../image';
import styles from './index.module.css';

interface UploadModalProps<T = string> {
    packetKey?: string;
    value?: T;
    onChange?: (value: T) => void;
    limit?: number;
    style?: React.CSSProperties;
    column?: number;
}

export default function UploadModal<T>(props: UploadModalProps<T>) {
    const { packetKey = "common", value, onChange, style, limit = 1, column = 5 } = props;
    const [visible, setVisible] = useState(false);

    const [root, setRoot] = useState<HTMLDivElement>(null);

    const multi = useMemo(() => {
        return limit > 1;
    }, [])

    useEffect(() => {
        const div = document.createElement('div');
        document.body.appendChild(div);
        setRoot(div);

        return () => {
            document.body.removeChild(div);
        }
    }, [])

    const pictures = useMemo(() => {
        if (typeof value == 'string') {
            return [value].filter(v => !!v);
        } else {
            return (value || []).filter(v => !!v);
        }
    }, [value])

    return (
        <div className={styles['upload-modal']} style={{ gridTemplateColumns: `repeat(${column}, 1fr)` }}>
            {
                ((!multi && pictures.length === 0) || multi) && <div
                    style={style}
                    className={styles['upload-selector']}
                    onClick={() => setVisible(true)}
                >
                    <Icon name="picture" color="#c1c1c1" size={32} />
                </div>
            }

            {
                pictures.map(picture => {
                    return <div className={styles['upload-selector']}>
                        <Image src={picture} />
                        <Icon
                            onClick={() => {
                                const index = pictures.findIndex(pic => pic === picture);
                                pictures.splice(index, 1);
                                onChange?.([...pictures])
                            }}
                            name="close-circle"
                            size={32}
                            className={styles['upload-close']}
                            color="#ccc" />
                    </div>
                })
            }

            {visible && createPortal(< Hub
                packetKey={packetKey}
                onClose={() => setVisible(false)}
                onChange={picture => {
                    if (multi) {
                        onChange?.([...pictures, picture])
                    } else {
                        onChange?.(picture)
                    }
                    setVisible(false);
                }} />, root)}
        </div>
    )
}
