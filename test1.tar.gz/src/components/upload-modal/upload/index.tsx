import React, { ReactNode, useRef, useState } from 'react';
import { uploadMaterial } from '@/service/material';

interface UploadProps {
    packetKey?: string;
    children: ReactNode;
    onChange: any;
    classNames?: string;
}

export default function Upload(props: UploadProps) {
    const { packetKey, children, onChange, classNames } = props;

    const uploadRef = useRef<HTMLInputElement>(null);

    const [loading, setLoading] = useState(false);

    const upload = (file: File) => {
        setLoading(true);
        uploadMaterial({ file, packetKey }).then(res => {
            onChange?.(res.data);
        }).finally(() => {
            setLoading(false);
        })
    }

    return (
        <div className={classNames}>
            {
                loading ?
                    <span>loading...</span>
                    :
                    <div style={{ width: '100%', height: '100%' }} onClick={() => {
                        uploadRef.current?.click();
                    }}>
                        {children}
                    </div>
            }
            <input
                ref={uploadRef}
                type="file"
                style={{ display: 'none' }}
                onChange={(value) => {
                    const file = value.target.files?.[0];
                    if (file) {
                        upload(file)
                    }
                }}
            />
        </div>
    )
}
