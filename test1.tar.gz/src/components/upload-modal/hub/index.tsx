import React from 'react';
// import { createPortal } from 'react-dom';
import { Pagination } from 'antd';
import { useRequest } from '@umijs/hooks';
import { Icon } from 'dumbooo';
import { getMaterials } from '@/service/material';
import UploadComponent from '../upload';
import Image from '../../image';
import styles from './index.module.css';

interface UploadModalProps {
    packetKey?: string;
    /* eslint-disable */
    onChange: (value: string) => void;
    onClose: () => void;
}

export default function Upload(props: UploadModalProps) {
    const { packetKey = "blog", onClose, onChange } = props;

    const loadMaterials = (params: any) => {
        const { current, pageSize } = params;
        return getMaterials({ pn: current, ps: pageSize, packet: packetKey }).then(result => {
            const { count, data } = result;
            return {
                list: data.map(itme => ({ ...itme, link: `https://cdn.jsdelivr.net/gh/levenx/picture@master/material/${itme.fileKey}` })), total: count
            }
        })

    }

    const { data, loading, pagination, run } = useRequest(loadMaterials, { paginated: true, defaultParams: [{ current: 1, pageSize: 19 }] });

    return (
        <div className={styles['upload']}>
            <div className={styles['upload-body']}>
                <div className={styles['upload-head']}></div>
                <div className={styles['upload-content']}>
                    {
                        loading ?
                            new Array(15).fill(0).map((item, inx) => {
                                return <div key={`${item}_${inx}`} className={`${styles['upload-content__item']} ${styles['upload-skeleton']}`} />
                            }) :
                            <>
                                <UploadComponent
                                    packetKey={packetKey}
                                    classNames={styles['upload-content__item']}
                                    onChange={() => {
                                        run({ current: 1, pageSize: 19 });
                                    }}>
                                    <div className={`${styles['upload-content__item']}`}>
                                        <Icon name="picture" size={32} color="#c1c1c1" />
                                    </div>
                                </UploadComponent>

                                {
                                    data?.list?.map((item) => {
                                        return <div key={item.id} className={styles['upload-content__item']} onClick={() => onChange(item.link)}>
                                            <Image src={item.link} />
                                        </div>
                                    })
                                }
                            </>
                    }
                </div>
                <div className={styles['upload-footer']}>
                    <Pagination {...pagination} />
                </div>
            </div>
            <div className={styles['upload-mask']} onClick={onClose}></div>
        </div>
    )
}
