import React, { useState, useMemo } from 'react';
import { Pagination, Button, Form } from 'antd';
import { useAntdTable } from '@umijs/hooks';
import { IPageResponse, IResponse } from '@/service/request';
import ModeSwitch from '../mode-switch';
import './index.less';

export interface DataProps<T> {
    dataSource?: Array<T>;
    loading?: boolean;
    pagination?: {
        current: number;
        pageSize: number;
        total: number;
    };
    refresh?: () => void;
    onOpenDetail?: (current: any) => void;
}

interface Params {
    current: number;
    pageSize: number;
    [key: string]: any;
}

interface DataManageProps<Item> {
    title: string;
    defaultMode?: 'list' | 'block';
    children: Array<any>;
    fetchList: (params: Params) => Promise<IPageResponse<Item>>;
    fetchOnly: (id: number) => Promise<IResponse<any>>;
    extra?: any;
    isMode?: boolean;
}

export default function DataManage<Item>(props: DataManageProps<Item>) {
    const { title, defaultMode = "block", children, fetchList, fetchOnly, extra, isMode = true } = props;
    const [mode, setMode] = useState(defaultMode);
    const [current, setCurrent] = useState<any>(null);

    const [keywords, setKeywords] = useState({});

    const [TableComponent, BlockComponent, EditComponent, ...rest] = children;

    const { table, search, refresh } = useAntdTable<IPageResponse<Item>, Item>((params) => fetchList({ ...params, ...keywords }), [keywords], {
        defaultPageSize: 20,
    });

    const onOpenDetail = async (id: number) => {
        let { data } = await fetchOnly(id);
        setCurrent(data);
    }

    return (
        <div className="data-manage">
            <div className="data-manage__head">
                <div className="data-manage__head--left">
                    {title}({table?.pagination.total})
                </div>
                <div className="data-manage__head--right">
                    {
                        extra && React.cloneElement(extra, {
                            ...table,
                            refresh,
                            onKeywordChange: (key: string, value: any) => setKeywords({ ...keywords, [key]: value }),
                        })
                    }
                    <Button type="primary" onClick={() => setCurrent({})}>新增</Button>
                    {
                        isMode && <ModeSwitch mode={mode} onSwitch={setMode} />
                    }
                </div>
            </div>
            <div className="data-manage__body">
                {
                    mode === 'list' && React.cloneElement(TableComponent, { ...table, refresh, onOpenDetail })
                }
                {
                    mode === 'block' && React.cloneElement(BlockComponent, { ...table, refresh, onOpenDetail })
                }
                {
                    React.cloneElement(EditComponent, {
                        visible: Boolean(current),
                        onClose: (status: boolean) => {
                            setCurrent(null);
                            if (status) {
                                refresh();
                            }
                        },
                        defaultValue: current
                    })
                }
            </div>
            <div className="data-manage__foot">
                <Pagination {...table?.pagination} size="default" />
            </div>
        </div>
    )
}
