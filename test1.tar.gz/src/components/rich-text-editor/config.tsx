import React from 'react';
import {
    RedoPlugin,
    AlignCenterPlugin,
    AlignLeftPlugin,
    AlignRightPlugin,
    BoldPlugin,
    HrPlugin,
    ItalicPlugin,
    ListItemPlugin,
    BulletListPlugin,
    OrderedListPlugin,
    UndoPlugin,
} from '@syllepsis/plugin-basic';
import { TablePlugin } from '@syllepsis/plugin-table';
import { ColorPlugin, ImagePlugin, LinkPlugin, EmojiPlugin } from '@syllepsis/access-react';
import { SylPlugin, SylUnionPlugin, IConfigPluginObj } from '@syllepsis/adapter';
import { uploadMaterial } from '@/service/material';
import { Spin, Message } from '@arco-design/web-react';

interface IRichTextConfig {
    plugin: SylPlugin | SylUnionPlugin | IConfigPluginObj;
    tool: string;
    tooltip: string;
}

interface IRichTextConfigParams {
    onLoadingChange?: (status: boolean) => void;
}


export const richTextConfig = (
    { onLoadingChange }: IRichTextConfigParams
): IRichTextConfig[] => [
        { plugin: new ListItemPlugin(), tool: '', tooltip: '' },
        {
            plugin: new RedoPlugin(),
            tool: RedoPlugin.getName(),
            tooltip: "回滚",
        },
        {
            plugin: new UndoPlugin(),
            tool: UndoPlugin.getName(),
            tooltip: "回退",
        },
        {
            plugin: new AlignLeftPlugin(),
            tool: AlignLeftPlugin.getName(),
            tooltip: "文字居左",
        },
        {
            plugin: new AlignRightPlugin(),
            tool: AlignRightPlugin.getName(),
            tooltip: "文字居右",
        },
        {
            plugin: new AlignCenterPlugin(),
            tool: AlignCenterPlugin.getName(),
            tooltip: "文字居中",
        },
        {
            plugin: new ColorPlugin(),
            tool: ColorPlugin.getName(),
            tooltip: "文字颜色",
        },
        {
            plugin: new BoldPlugin(),
            tool: BoldPlugin.getName(),
            tooltip: "文字加粗",
        },
        {
            plugin: new ItalicPlugin(),
            tool: ItalicPlugin.getName(),
            tooltip: "斜体",
        },
        {
            plugin: new LinkPlugin(),
            tool: LinkPlugin.getName(),
            tooltip: "链接",
        },
        {
            plugin: new TablePlugin({
                button: {
                    activeColor: '#FF0F0F',
                    trigger: 'click',
                },
                columnResize: { handleWidth: 5, cellMinWidth: 24 },
                table: {
                    allowTableNodeSelection: false,
                    defaultCellWidth: 100,
                    useTableHeader: false,
                },
            }),
            tool: TablePlugin.getName(),
            tooltip: "表格",
        },
        {
            plugin: new BulletListPlugin(),
            tool: BulletListPlugin.getName(),
            tooltip: "有序列表",
        },
        {
            plugin: new OrderedListPlugin(),
            tool: OrderedListPlugin.getName(),
            tooltip: "无序列表",
        },
        {
            plugin: new HrPlugin(),
            tool: HrPlugin.getName(),
            tooltip: "分割线",
        },
        {
            plugin: new ImagePlugin({
                uploadType: 'file',
                listenDrop: true,
                listenPaste: true,
                placeholder: '众鑫建材网',
                uploader: async (img: File | Blob | string) => {
                    if (typeof img === 'string') return '';
                    let result = await uploadMaterial({ file: img, packetKey: 'material' });
                    return `https://cdn.jsdelivr.net/gh/levenx/picture@master/material/${result.data.fileKey}`;
                },
                renderLoading: (props: any) => {
                    onLoadingChange?.(props.state.uploading)
                    return <div className="rich-text__loading"><Spin loading={true}></Spin></div>
                }
            }),
            tool: ImagePlugin.getName(),
            tooltip: "图片"
        },
        {
            plugin: new EmojiPlugin(),
            tool: EmojiPlugin.getName(),
            tooltip: "表情",
        },
    ];