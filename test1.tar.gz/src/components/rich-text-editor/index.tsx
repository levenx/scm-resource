import './index.less';

import { SylEditor } from '@syllepsis/access-react';
import {
    EventChannel,
    SylApi,
    SylPlugin,
    SylUnionPlugin,
    IConfigPluginObj,
} from '@syllepsis/adapter';
import { ToolbarLoader } from '@syllepsis/editor';
import React, { useCallback, useEffect, useMemo, useRef } from 'react';
import classnames from 'classnames';
import { richTextConfig } from './config';

interface IRichTextEditorProps {
    value?: string;
    onChange?: (value: string) => void;
    onLoadingChange?: (status: boolean) => void;
    placeholder?: string;
    shouldAutoFocus?: boolean;
    isFixedHeight?: boolean;
    className?: string;
}

interface IReadOnlyRichProps {
    value?: string;
    isReadonly?: boolean;
}

function Editor(props: IRichTextEditorProps) {
    const { value, onChange, onLoadingChange, placeholder, shouldAutoFocus = false, isFixedHeight = false, className } = props;

    const { plugins, tools, tooltips } = useMemo(
        () =>
            richTextConfig({ onLoadingChange }).reduce<{
                plugins: (SylPlugin | SylUnionPlugin | IConfigPluginObj)[];
                tools: string[];
                tooltips: Record<string, string>;
            }>(
                (memo, item) => {
                    const { plugin, tool, tooltip } = item;
                    memo.plugins.push(plugin);
                    if (tool) {
                        memo.tools.push(tool);
                    }
                    if (tool && memo.tooltips) {
                        memo.tooltips[tool] = tooltip;
                    }
                    return memo;
                },
                {
                    plugins: [],
                    tools: [],
                    tooltips: {},
                },
            ),
        [onLoadingChange],
    );

    const module = {
        toolbar: {
            Ctor: ToolbarLoader,
            option: {
                tools,
                tooltips,
            },
        },
    };

    const editorRef = useRef<SylApi>();

    const getEditor = useCallback((editor: SylApi) => {
        editorRef.current = editor;
    }, []);

    useEffect(() => {
        const handler = () => {
            onChange?.(editorRef.current?.getHTML() || '');
        };

        editorRef.current?.on(EventChannel.LocalEvent.TEXT_CHANGED, handler);

        return () => {
            editorRef.current?.off(EventChannel.LocalEvent.TEXT_CHANGED, handler);
        };
    }, [onChange]);

    useEffect(() => {
        if (shouldAutoFocus) {
            editorRef.current?.focus();
        }
    }, [shouldAutoFocus]);

    // 当外部传入的value与editor自身value不相同，将editor自身value设置成传入的value
    useEffect(() => {
        const editorValue = editorRef.current?.getHTML();
        if (editorValue !== value) {
            editorRef.current?.setHTML(value);
        }
    }, [value]);

    return (
        <div className={classnames("rich-editor", className, { 'athena-editor__fixed': isFixedHeight })}>
            <SylEditor
                placeholder={placeholder}
                getEditor={getEditor}
                plugins={plugins}
                module={module}
            />
        </div>
    );
}

export default function RichTextEditor(props: IRichTextEditorProps & IReadOnlyRichProps) {
    return <Editor {...props} />;
}
