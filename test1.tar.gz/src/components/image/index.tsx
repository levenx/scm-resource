import React, { useState, useEffect } from 'react';
import styles from './index.module.css';

interface ImageProps {
    src: string;
    alt?: string;
    className?: string;
}

const ERROR_IMAGE_URL = 'https://cdn.jsdelivr.net/gh/levenx/picture@master/material/df5341f8090843ad9b34284f6dba12b6.jpg';

export default function CustomImage(props: ImageProps) {
    const { src, alt, className = '' } = props;

    const [targetUrl, setTargetUrl] = useState(src);

    useEffect(() => {
        setTargetUrl(ERROR_IMAGE_URL);
        const image = new Image();
        image.src = src;
        image.onload = () => {
            setTargetUrl(src);
        }
    }, [])

    const onError = () => {
        setTargetUrl(ERROR_IMAGE_URL);
    }

    return (
        <img src={targetUrl} alt={alt} onError={onError} className={className} />
    )
}
