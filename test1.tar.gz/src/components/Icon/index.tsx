import React from 'react'

interface IconProps {
    name: string;
    size?: number;
    color?: string;
    className?: string;
    onClick?: () => void;
}

export default function Icon(props: IconProps) {
    const { name, size = 24, color, className, onClick } = props;
    return (
        <i className={`iconfont icon-${name} ${className}`} style={{ fontSize: size, color }} onClick={onClick}></i>
    )
}
