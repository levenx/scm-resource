import React from 'react';
import { Input } from 'antd';
import './index.less';

interface TextAreaProps {
    value?: string;
    onChange?: (value: string) => void;
}

export default function TextArea(props: TextAreaProps) {
    const { value, onChange } = props;
    return (
        <Input.TextArea className="text-area" value={value} onChange={event => onChange(event.target.value)} />
    )
}
