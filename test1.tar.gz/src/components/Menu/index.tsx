import React from 'react'
import { NavLink } from 'react-router-dom';
import Icon from '../Icon';
import './index.less';

const menus = [
    { path: '/', icon: 'all', title: '总览页' },
    { path: '/goods', icon: 'assessed-badge', title: '商品资产' },
    { path: '/cases', icon: 'assessed-badge', title: '案例资产' },
    { path: '/news', icon: 'assessed-badge', title: '新闻资产' },
    // { path: '/spider', icon: 'spider', title: '爬虫管理' },
    { path: '/chat', icon: 'chat', title: '在线服务' },
    { path: '/setting', icon: 'setting', title: '项目设置' },
    { path: '/report', icon: 'Union', title: '报表' },
]

export default function Menu() {
    return (
        <nav className="menu">
            {
                menus.map(menu => {
                    return <NavLink
                        key={menu.path}
                        to={menu.path}
                        className="menu-item"
                        activeClassName="menu-item--active"
                        // 处理严格路由问题
                        exact={menu.path === '/'}
                    >
                        <Icon name={menu.icon} />
                        <span>{menu.title}</span>
                    </NavLink>
                })
            }
            {/* <SuperLogo className="xxx" style={{ width: '100%' }} /> */}
        </nav >
    )
}
