import React from 'react'
import Icon from '../Icon';
import './index.less';

export default function Logo() {
    return (
        <div className="logo">
            <h1>Material</h1>
        </div>
    )
}
