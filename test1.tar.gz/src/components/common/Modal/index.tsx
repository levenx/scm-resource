import React from 'react';
import { Modal } from 'antd';

interface BaseModalProps {
    visible: boolean;
    title?: string;
    children: any;
    onOk?: () => void;
    onCancel?: () => void;
}

export default function BaseModal(props: BaseModalProps) {
    const { visible, children, title, onOk, onCancel } = props;
    return (
        <Modal
            title={title}
            visible={visible}
            style={{ top: 300 }}
            onOk={onOk}
            onCancel={onCancel} footer={null}>
            {children}
        </Modal>
    )
}
