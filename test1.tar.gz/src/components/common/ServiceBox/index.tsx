import React from 'react'
import Icon from '../../Icon';

import './index.less';

export default function ServiceBox() {
    return (
        <div className="service-box">
            <div className="service-box__icon">
                <Icon name="coupons" size={48} color="#fff"/>
            </div>
            <div className="service-box__content">
                <span className="service-box__content--number">
                    10,475
                </span>
                <span className="service-box__content--label">
                    Total Sales
                </span>
            </div>
        </div>
    )
}
