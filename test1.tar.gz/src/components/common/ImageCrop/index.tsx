import React, { useState, useEffect, useRef, useCallback, forwardRef, useImperativeHandle } from 'react';
import { Modal } from 'antd';
import ReactCrop, { Crop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import './index.less';

interface ImageCropProps {
    file: File;
}

export const ImageCrop = forwardRef(function (props: ImageCropProps, ref) {

    const { file } = props;

    const [crop, setCrop] = useState<Crop>({ unit: '%', width: 100, aspect: 16 / 9 });
    const [completedCrop, setCompletedCrop] = useState<any>(null);
    const [originImage, setOriginImage] = useState<any>();

    const imageRef = useRef(null);
    const previewCanvasRef = useRef(null);

    const onLoad = useCallback((img) => {
        imageRef.current = img;
    }, []);

    const onComplete = () => new Promise((resolve, reject) => {
        const canvas = previewCanvasRef.current as any;
        const crop = completedCrop;
        if (!crop || !canvas) {
            return;
        }
        canvas.toBlob(
            (blob: any) => {
                resolve(blob);
            },
            'image/png',
            1
        );
    })

    useImperativeHandle(ref, () => ({
        onComplete
    }))

    useEffect(() => {
        const reader = new FileReader();
        reader.addEventListener('load', () => setOriginImage(reader.result));
        reader.readAsDataURL(file);
    })


    useEffect(() => {
        if (!completedCrop || !previewCanvasRef.current || !imageRef.current) {
            return;
        }

        const image = imageRef.current as any;
        const canvas = previewCanvasRef.current as any;
        const crop = completedCrop;

        const scaleX = image.naturalWidth / image.width;
        const scaleY = image.naturalHeight / image.height;
        const ctx = canvas.getContext('2d');
        const pixelRatio = window.devicePixelRatio;

        canvas.width = crop.width * pixelRatio;
        canvas.height = crop.height * pixelRatio;

        ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
        ctx.imageSmoothingQuality = 'high';

        ctx.drawImage(
            image,
            crop.x * scaleX,
            crop.y * scaleY,
            crop.width * scaleX,
            crop.height * scaleY,
            0,
            0,
            crop.width,
            crop.height
        );
    }, [completedCrop]);

    return (
        <>
            <ReactCrop
                className="image-crop__origin"
                imageStyle={{ height: '100%', minHeight: 500 }}
                src={originImage}
                onImageLoaded={onLoad}
                crop={crop}
                onChange={(c) => setCrop(c)}
                onComplete={(c) => {
                    setCompletedCrop(c)
                }}
            />
            <div className="image-crop__target" style={{ display: 'none' }}>
                <canvas
                    ref={previewCanvasRef}
                    style={{
                        width: Math.round(completedCrop?.width ?? 0),
                        height: Math.round(completedCrop?.height ?? 0)
                    }}
                />
            </div>
        </>
    )
})

export default ImageCrop;

export function useImageCrop() {

    const imageRef = useRef<any>();


    const showCrop = (file: File) => new Promise((resolve, reject) => {

        const model = Modal.info({
            title: null,
            icon: null,
            className: "image-crop",
            bodyStyle: { display: 'flex', flex: '1 1 auto' },
            closable: false,
            content: (
                <ImageCrop file={file} ref={imageRef} />
            ),
            onOk: () => new Promise((success, __) => {
                imageRef.current?.onComplete().then((blob: Blob) => {
                    resolve(blob);
                    success(null);
                }, reject);

            }),
            cancelText: "取消"
        })
    })
    return {
        showCrop,
    }
}
