import React, { useRef } from 'react';
import { Progress } from 'antd';
import useUpload from '@/hooks/useUpload';
import Icon from '@/components/Icon';
import './index.less';



interface UploadProps {
    value: Array<string>;
    onChange: (value: Array<string>) => void;
}

export default function Upload(props: UploadProps) {
    const { value = [], onChange } = props;
    const inputRef = useRef<any>(null);
    const { upload, clear, loading, process, data, error } = useUpload({ crop: true });

    const onFilePick = (files: File[]) => {
        if (files.length > 0) {
            upload(files[0]);
        }
    }

    const onRemove = (picture: string, inx: number) => {
        const pictures = [...value];
        pictures.splice(inx, 1);
        onChange(pictures);
    }

    if (data) {
        const pictures = [...value, data];
        onChange(pictures);
        clear();
    }


    return (
        <div className="upload">
            {
                value.map((pic, inx) => {
                    return <div key={pic} className="upload-preview">
                        <img src={pic || data || ''} className="common-upload--preview" />
                        <div className="upload-icon" onClick={onRemove.bind(null, pic, inx)}><Icon name="chahao" color="#888" size={24} /></div>
                    </div>
                })
            }
            <div className="common-upload" onClick={() => inputRef.current?.click()}>
                <input ref={inputRef} style={{ display: 'none' }} type="file" name="file" onChange={(e: any) => onFilePick(e.target.files)} />
                {
                    loading ? <div className="common-upload--loading">
                        <Progress type="circle" percent={parseInt(process?.percent)} width={80} />
                    </div>
                        :
                        <div className="common-upload--empty">
                            <Icon name="upload" size={36} />
                            <span>图片上传</span>
                        </div>
                }
                {
                    error && <div className="common-upload--error">error</div>
                }

            </div>
        </div>
    )
}
