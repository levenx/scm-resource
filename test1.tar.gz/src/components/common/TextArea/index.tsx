import React from 'react'

import './index.less';

interface TextAreaProps {
    value: string;
    onChange: (value: string) => void;
}

export default function TextArea(props: TextAreaProps) {
    const { value, onChange } = props;
    return (
        <div className="common-textarea">
            <textarea className="textarea" value={value} onChange={e => onChange(e.target.value)}></textarea>
        </div>
    )
}
