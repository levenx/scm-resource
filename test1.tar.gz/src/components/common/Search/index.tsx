import React, { useState } from 'react'
import Icon from '../../Icon';
import './index.less';

interface SearchProps {
    onSearch?: (value: string) => void
}

export default function Search(props: SearchProps) {
    const { onSearch } = props;
    const [value, setVal] = useState<string>("");
    return (
        <div className="common-search">
            <input className="common-search--input" value={value} onChange={e => setVal(e.target.value)} placeholder="请输入搜索内容"/>
            <Icon name="search" color="#847780" className="common-search--icon" onClick={() => onSearch?.(value)} />
        </div>
    )
}
