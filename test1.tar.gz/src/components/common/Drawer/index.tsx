import React from 'react';
import { Drawer, Modal } from 'antd';

import './index.less';

interface BaseDrawerProps {
    visible: boolean;
    footer: any;
    children: any;
    onClose?: () => void;
}

export default function BaseDrawer(props: BaseDrawerProps) {
    const { children, visible, onClose, footer } = props;

    const beforeClose = () => {
        Modal.confirm({
            style: { top: 300 },
            title: 'Confirm',
            content: 'Bla bla ...',
            okText: '确认',
            cancelText: '取消',
            onOk: onClose
        });
    }

    return (
        <>
            <Drawer
                placement="right"
                width="600"
                onClose={() => {
                    beforeClose()
                }}
                footer={footer}
                visible={visible}
            >
                {children}
            </Drawer>
        </>
    )
}
