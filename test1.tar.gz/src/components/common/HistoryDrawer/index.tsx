import React, { useState, forwardRef, useImperativeHandle, useCallback } from 'react';
import { Drawer, Steps, Modal } from 'antd';
import { DrawerContext } from './drawerContext';
import './index.less';

const { Step } = Steps;

interface StepProps {
    title: string;
}

interface HistoryDrawerProps {
    visible: boolean;
    title?: string;
    loading?: boolean;
    children: any;
    onClose?: () => void;
    steps: Array<StepProps>;
}

export default forwardRef(function HistoryDrawer(props: HistoryDrawerProps, ref) {
    const { visible, children, onClose, steps, loading, title } = props;

    const [inx, setInx] = useState<number>(0);

    const beforeClose = () => {
        Modal.confirm({
            style: { top: 300 },
            title: '当前页面编辑中，确认离开吗？',
            icon: null,
            okText: '离开',
            okButtonProps: { type: 'primary' },
            okType: 'danger',
            cancelText: '取消',
            onOk: onClose
        });
    }

    const onNext = () => {
        setInx(inx + 1);
    }

    const onBack = () => {
        setInx(inx - 1);
    }

    const onRest = () => {
        setInx(0);
    }

    useImperativeHandle(ref, () => ({
        onNext,
        onBack,
        onRest
    }))

    const component = useCallback(
        () => {
            if (!Array.isArray(children)) {
                throw new Error();
            }
            return children[inx];
        },
        [inx],
    )


    return (
        <DrawerContext.Provider value={{ current: inx, onNext, onBack, onRest }}>
            <Drawer
                placement="right"
                title={<div className="history-drawer__header">
                    <div className="history-drawer__header--title">{title}</div>
                    <div className="history-drawer__header--step" style={{ width: 180 * 2 }}>
                        <Steps size="small" current={inx} type="navigation">
                            {
                                steps.map(step => {
                                    return <Step key={step.title} title={step.title} />
                                })
                            }
                        </Steps>
                    </div>
                </div>}
                headerStyle={{ padding: 0 }}
                bodyStyle={{ padding: 0, display: 'flex', flexDirection: 'column' }}
                width="900"
                closable={false}
                onClose={() => {
                    beforeClose()
                }}
                visible={visible}
            >
                {loading ? <div>loading...</div> : React.createElement(component)}
            </Drawer>
        </DrawerContext.Provider>
    )
})
