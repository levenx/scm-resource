import React from 'react';
import classnames from 'classnames';
import Icon from '../Icon';
import './index.less';


type Mode = 'list' | 'block';
interface ModeSwitchProps {
    mode: Mode;
    onSwitch: (mode: Mode) => void;
}

const modes: Array<{ icon: string; type: Mode }> = [
    { icon: 'category', type: 'list' },
    { icon: 'all', type: 'block' }
]

export default function ModeSwitch(props: ModeSwitchProps) {
    const { mode: currentMode = 'list', onSwitch } = props;
    return (
        <div className="mode-switch">
            {
                modes.map(mode => {
                    return <div
                        key={mode.type}
                        onClick={() => onSwitch(mode.type)}
                        className={classnames("mode-switch--item",
                            {
                                'mode-switch--active': currentMode === mode.type,
                                'mode-switch__left--active': currentMode === 'list',
                                'mode-switch__right--active': currentMode === 'block'
                            })}>
                        <Icon name={mode.icon} className="mode-switch--icon" size={18} />
                    </div>
                })
            }
        </div>
    )
}
