import React from 'react';
import { Cascader } from 'antd';
import useCategory from '@/views/asset/hooks/useCategory';

interface CategoryTreeProps {
    value?: string[];
    onChange?: (value: string[]) => void;
}

export default function CategoryTree(props: CategoryTreeProps) {
    const { value, onChange } = props;

    const { data: category } = useCategory(false);
    console.log('category:', category)

    return (
        <Cascader
            value={value}
            onChange={(value: any) => onChange?.(value)}
            options={category?.data} />
    )
}
