import React, { useState, useEffect } from 'react';
import { Cascader } from 'antd';
import { loadItemizeSelect } from '@/service/itemize';
import './index.less';

interface ItemizePickerProps {
    value?: Array<string>;
    onChange?: (value: string[]) => void;
}

export default function ItemizePicker(props: ItemizePickerProps) {
    const [options, setOptions] = useState([]);
    const { value, onChange } = props;

    useEffect(() => {
        loadItemizeSelect().then(res => {
            setOptions(res.data)
        })
    }, [])

    return (
        <div>

            <Cascader
                // defaultValue={value}
                options={options}
                value={value}
                onChange={(value: any) => {
                    onChange?.(value);
                }} />

        </div>
    )
}
