import React, { useEffect, useState, useCallback, forwardRef, useImperativeHandle } from 'react';
import { Table, Input, Button, Popconfirm } from 'antd';
import { useAntdTable, useMap } from '@umijs/hooks';
import { createItemize, loadItemize, deleteItemize } from '@/service/itemize';
import { ItemProps, getTableData, count } from './index';

interface ExpandItemizeProps {
    itemId: number;
}

export default forwardRef(function ExpandItemize(props: ExpandItemizeProps, ref) {
    const { itemId } = props;
    const [data, setData] = useState<Array<any>>([]);
    const [map, { get, set, remove }] = useMap();






    useEffect(() => { }, [])

    const { tableProps, refresh } = useAntdTable(e => getTableData({ ...e, pid: itemId }), {});
    const { loading, dataSource } = tableProps;

    useEffect(() => {
        setData([...dataSource])
    }, [dataSource])

    const onChange = (row: number, col: string, value: string) => {
        const rowData: any = { ...data[row] };
        rowData[col] = value;
        data[row] = rowData;
        setData([...data])
    }

    const onAdd = useCallback(() => {
        const id = count();
        const initData: ItemProps = { id, title: '', type: '', weight: '' }
        setData([initData, ...data,]);
        set(id, initData);
    }, [data]);

    const onEdit = useCallback((item: ItemProps) => {
        set(item.id, item);
    }, [data])

    const onCancel = useCallback((index: number, item: ItemProps) => {
        const history: ItemProps = get(item.id) as ItemProps;
        if (history.id < 0) {
            data.splice(index, 1);
        } else {
            data.splice(index, 1, history);
        }
        setData([...data]);
        remove(item.id);
    }, [data]);


    const onSave = async (item: ItemProps) => {
        let { code, data } = await createItemize(item) as any;
        if (code === 0) {
            remove(item.id);
            refresh();
        }
    }

    useImperativeHandle(ref, () => ({
        onAdd
    }))

    const columns = [
        {
            title: '标题',
            dataIndex: 'title',
            width: 200,
            render: (text: string, item: ItemProps, index: number) => {
                return get(item.id) ? <Input value={text} onChange={(e) => onChange(index, 'title', e.target.value)} /> : <div>{text}</div>
            }
        },
        {
            title: '标签',
            dataIndex: 'type',
            width: 200,
            render: (text: string, item: ItemProps, index: number) => {
                return get(item.id) ? <Input value={text} onChange={(e) => onChange(index, 'type', e.target.value)} /> : <div>{text}</div>
            }
        },
        {
            title: '权重',
            dataIndex: 'weight',
            width: 200,
            render: (text: string, item: ItemProps, index: number) => {
                return get(item.id) ? <Input value={text} onChange={(e) => onChange(index, 'weight', e.target.value)} /> : <div>{text}</div>
            }
        },
        {
            title: '操作',
            render: (_: any, item: ItemProps, index: number) => {
                return get(item.id) ?
                    <div className="operate">
                        <Button type="link" onClick={onSave.bind(null, Object.assign(item, { pid: itemId }))} className="operate--item">保存</Button>
                        <Button type="text" style={{ color: '#ccc' }} className="operate--item" onClick={onCancel.bind(null, index, item)}>取消</Button>
                    </div>
                    :
                    <div className="operate">
                        <Button type="link" onClick={onEdit.bind(null, item)}>编辑</Button>
                        <Popconfirm title="确认删除本行数据？"
                            okText="删除"
                            okType="danger"
                            cancelText="取消"
                            onConfirm={async () => {
                                let result = await deleteItemize(item.id) as any;
                                if (result.code === 0) {
                                    refresh();
                                }
                            }}>
                            <Button type="link" danger>删除</Button>
                        </Popconfirm>
                    </div>

            }
        },
    ];

    return (
        <Table
            columns={columns}
            rowKey="id"
            className="expand--wrapper"
            pagination={false}
            dataSource={data}
            showHeader={false}
            loading={loading}
        />
    )
})
