import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { useMap, useAntdTable } from '@umijs/hooks';
import { Modal, Button, Space, Input, Table, Popconfirm } from 'antd';
import Icon from '@/components/Icon';
import { createItemize, loadItemize, deleteItemize } from '@/service/itemize';
import ExpandItemize from './ExpandItemize';
import './index.less';

interface ItemizeHeaderProps {
    onAdd: () => void;
    onClose: () => void;
}

export interface ItemProps {
    id: number;
    title: string;
    type: string;
    weight: number | string;
}

export const count = (function () {
    let num = 0;
    return () => {
        return --num;
    }
})();

function ItemizeHeader(props: ItemizeHeaderProps) {
    const { onAdd, onClose } = props;
    return <div className="itemize-header">
        <div>产品类型</div>
        <Space>
            <Icon name="delete" size={14} color="#666" className="itemize-close" onClick={onClose} />
        </Space>
    </div>
}

export const getTableData = ({ current, pageSize, pid }: any) => {
    return loadItemize(pid, current, pageSize).then((res: any) => {
        const { total, data } = res;
        return {
            total,
            data
        }
    })
};

export default function ProductItemize() {
    const history = useHistory();
    const [data, setData] = useState<Array<any>>([]);
    const [open, setOpen] = useState<number | null>(null);
    const [map, { set, remove, get }] = useMap();
    const secondRef = useRef(null);

    const { tableProps, refresh } = useAntdTable(getTableData, {});
    const { dataSource } = tableProps;

    useEffect(() => {
        setData([...dataSource])
    }, [dataSource])

    const onClose = useCallback(() => { history.push(`${location.pathname}`) }, []);

    const onAdd = useCallback(() => {
        const id = count();
        const initData = { id, title: '', type: '', weight: '' }
        setData([initData, ...data,]);
        set(id, initData);
    }, [data]);

    const onEdit = useCallback((item: ItemProps) => {
        set(item.id, item);
    }, [data])

    const onCancel = useCallback((index: number, item: ItemProps) => {
        const history: ItemProps = get(item.id) as ItemProps;
        if (history.id < 0) {
            data.splice(index, 1);
        } else {
            data.splice(index, 1, history);
        }
        setData([...data]);
        remove(item.id);
    }, [data]);

    const onSave = async (item: ItemProps) => {
        let { code, data } = await createItemize(item) as any;
        if (code === 0) {
            remove(item.id);
            refresh();
        }
    }

    const onChange = (row: number, col: string, value: string) => {
        const rowData = { ...data[row] };
        rowData[col] = value;
        data[row] = rowData;
        setData([...data])
    }

    const columns = [
        {
            title: '标题',
            dataIndex: 'title',
            width: 200,
            key: 'title',
            render: (text: string, item: ItemProps, index: number) => {
                return get(item.id) ? <Input value={text} onChange={(e) => onChange(index, 'title', e.target.value)} /> : <div>{text}</div>
            }
        },
        {
            title: '标签',
            dataIndex: 'type',
            width: 200,
            key: 'type',
            render: (text: string, item: ItemProps, index: number) => {
                return get(item.id) ? <Input value={text} onChange={(e) => onChange(index, 'type', e.target.value)} /> : <div>{text}</div>
            }
        },
        {
            title: '权重',
            dataIndex: 'weight',
            width: 200,
            key: 'weight',
            render: (text: string, item: ItemProps, index: number) => {
                return get(item.id) ? <Input value={text} onChange={(e) => onChange(index, 'weight', e.target.value)} /> : <div>{text}</div>
            }
        },
        {
            title: '操作',
            render: (_: any, item: ItemProps, index: number) => {
                return get(item.id) ? <div className="operate">
                    <Button type="link" onClick={onSave.bind(null, item)} className="operate--item">保存</Button>
                    <Button type="text" style={{ color: '#ccc' }} onClick={onCancel.bind(null, index, item)} className="operate--item">取消</Button>
                </div>
                    :
                    <div className="operate">
                        {open === item.id ?
                            <Button type="link" onClick={() => setOpen(-1)}>关闭</Button> :
                            <Button type="link" onClick={() => setOpen(item.id)}>打开</Button>
                        }

                        {open === item.id && <Button type="link" onClick={() => (secondRef.current as any)?.onAdd()}>新增</Button>}
                        <Button type="link" onClick={onEdit.bind(null, item)}>编辑</Button>
                        <Popconfirm title="确认删除本行数据？"
                            okText="删除"
                            okType="danger"
                            cancelText="取消"
                            onConfirm={async () => {
                                let result = await deleteItemize(item.id) as any;
                                if (result.code === 0) {
                                    refresh();
                                }
                            }}>
                            <Button type="link" danger>删除</Button>
                        </Popconfirm>
                    </div>

            }
        },
    ];

    return (
        <Modal
            title={<ItemizeHeader onAdd={onAdd} onClose={onClose} />}
            visible={true}
            footer={null}
            closable={false}
            bodyStyle={{ padding: 0 }}
            width="40%">
            <Table
                columns={columns}
                rowKey="id"
                expandable={{
                    expandedRowClassName: () => "expand--wrapper",
                    expandIcon: () => null,
                    expandedRowRender: (record, index, indent, expanded) => {
                        return record.id === open ? <ExpandItemize itemId={record.id} ref={secondRef} /> : null
                    }
                }}
                footer={() => <Button type="primary" onClick={onAdd} style={{ width: '100%', height: 40 }}>新增</Button>}
                {...tableProps}
                dataSource={data}
            />
        </Modal >
    )
}
