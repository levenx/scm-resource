import React from 'react';
import { Switch, Rate, Tooltip, Button, Popconfirm, Progress, Image } from 'antd';
import { format } from '@/utils/time';
import { Column } from './config';

export const pasteColumns = (columns: Array<any>): Array<any> => {

    const result = columns.map(column => {
        column = { dataIndex: column.key, align: 'center', ellipsis: true, ...column, }

        switch (column.type) {
            case Column.Serial:
                column = serialRender(column);
                break;
            case Column.Time:
                column = timeRender(column);
                break;
            case Column.Status:
                column = statusRender(column);
                break;
            case Column.Rate:
                column = rateRender(column);
                break;
            case Column.Progress:
                column = progressRender(column);
                break;
            case Column.Tools:
                column = toolsRender(column);
                break;
            case Column.Image:
                column = imageRender(column);
                break;
            default:
                column = textRender(column);
                break;
        }
        return column;
    })
    return result;
}

function textRender(column: any) {
    return { ...column, dataIndex: column.key, render: column.render ? column.render : (text: string) => <Tooltip title={text}>{text}</Tooltip> }
}

function serialRender(column: any) {
    return {
        title: "序号",
        align: 'center',
        width: '80px',
        render: (text: any, record: any, inx: number) => {
            return <div className="table-inx"><span>{inx + 1}</span></div>
        },
        ...column
    };
}

function timeRender(column: any) {
    return { ...column, dataIndex: column.key, render: (time: string) => <span>{format(time)}</span> }
}

function statusRender(column: any) {
    const { onChange } = column;
    return {
        ...column, dataIndex: column.key, render: (status: number, { id }: any) => {
            let loading = false;
            const event = async () => {
                loading = true;
                await onChange();
                loading = false;
            }
            return <Switch size="small" checked={Boolean(status)} loading={loading} onChange={status => onChange(status, id)} />
        }
    }
}

function rateRender(column: any) {
    const { onChange } = column;
    return {
        ...column, dataIndex: column.key, render: (status: number, { id }: any) => {
            return <Rate className="table-rate" />
        }
    }
}

function imageRender(column: any) {
    const { onChange } = column;
    return {
        ...column, dataIndex: column.key, render: (value: string) => {
            const images = value.split(';');
            return <Image
                width={100}
                height={56}
                src={images?.[0]}
                placeholder={
                    <Image
                        preview={false}
                        src="https://cdn.jsdelivr.net/gh/levenx/picture@master/material/9b81f9b958b947a1b99333b749eb3150.jpeg"
                        width={100}
                        height={56}
                    />
                }
            />
        }
    }
}

function progressRender(column: any) {
    const { onChange } = column;
    return {
        ...column, dataIndex: column.key, render: (status: number, { id }: any) => {
            const random = Math.random() * 100;
            return <Progress percent={parseInt(String(random))} status="active" showInfo={false} />
        }
    }
}



function toolsRender(column: any) {
    const { tools } = column;
    return {
        ...column, dataIndex: column.key, render: (item: any) => {
            return <div>
                {
                    tools.map((tool: any) => {
                        switch (tool.type) {
                            case Column.Edit:
                                return <Button key={tool.type} type="link" onClick={() => tool.onClick?.(item)}>编辑</Button>
                            case Column.Delete:
                                return <Popconfirm key={tool.type} placement="topLeft" title={'确认删除吗'} onConfirm={() => {
                                    tool.onClick?.(item)
                                }} okType="danger" okText="删除" cancelText="取消">
                                    <Button type="link" danger>删除</Button>
                                </Popconfirm>
                        }
                    })
                }
            </div>
        }
    }
}