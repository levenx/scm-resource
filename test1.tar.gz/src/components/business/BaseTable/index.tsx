import React, { useState, forwardRef, useImperativeHandle } from 'react';
import { useAntdTable, useToggle } from '@umijs/hooks';
import { Table, Button, Space, ConfigProvider, Empty } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import Search from '@/components/common/Search';
import Icon from '@/components/Icon';
import { pasteColumns } from './utils';
import './index.less';

const baseColumn = (columns: Array<any>) => {
    const targetColumns = pasteColumns(columns);
    return targetColumns;
};

interface BaseTableProps {
    title: string;
    onTitleClick?: () => void;
    onAddClick?: () => void;
    columns: any[];
    loadData: any;
    additional?: any;
    current?: number;
    pageSize?: number;
}

interface Result {
    total: number;
    data: any[];
}

export default forwardRef(function BaseTable(props: BaseTableProps, ref) {
    const { title, onTitleClick, onAddClick, columns, loadData, additional, current, pageSize } = props;
    const { state: hover, toggle } = useToggle(false);
    const [keyword, setKeyWord] = useState('');

    const tableRes = useAntdTable<any, any>(e => loadData({ ...e, keyword }),
        { defaultParams: [{ current: current || 1, pageSize: pageSize || 10 },] });
    const { tableProps, refresh } = tableRes;
    const { pagination, loading, ...rest } = tableProps

    useImperativeHandle(ref, () => ({
        refresh
    }));


    return (
        <div className="general-table">
            <div className="general-table__header">
                <div className="general-table__header--title"
                    onClick={onTitleClick}
                    onMouseEnter={() => { toggle(true) }}
                    onMouseLeave={() => { toggle(false) }}>
                    <span>{title} <span className="data-number">({loading ? 'loading...' : pagination.total})</span></span>
                    {onTitleClick && hover && <Icon name="switch" className="event--click" />}
                </div>
                <div className="general-table__header--extra">
                    <Space>
                        <Search onSearch={(value: string) => {
                            setKeyWord(value)
                        }} />
                        {
                            additional
                        }
                        <Icon name="exchangerate" onClick={refresh} color="#555" className="pointer margin" />
                        <Button
                            type="primary"
                            className="add"
                            onClick={onAddClick}
                            icon={<PlusOutlined />}>新增</Button>
                    </Space>
                </div>
            </div>
            <div className="general-table__content">
                <ConfigProvider renderEmpty={() => <Empty />} >
                    <Table
                        rowKey="id"
                        rowClassName="general-table__content--row"
                        scroll={{ y: 700 }}
                        columns={baseColumn(columns)}
                        pagination={{ ...pagination, position: ['bottomCenter'] }}
                        loading={loading}
                        {...rest}
                    />
                </ConfigProvider>
            </div>
        </div>
    )
})