export enum Column {
    Serial = 1,
    Status = 2,
    Time = 3,
    Rate = 4,
    Progress = 5,
    Tag = 6,
    Image = 7,

    Tools = 10,
    Edit = 11,
    Delete = 12
}