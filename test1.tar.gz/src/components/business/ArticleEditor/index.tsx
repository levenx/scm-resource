import React, { forwardRef, useRef } from 'react';
import Editor from "for-editor";
import useUpload from '../../../hooks/useUpload1';
import './index.less';


interface ArticleEditorProps {
    value?: string;
    onChange?: (value: string) => void;
}

export default forwardRef(function (props: ArticleEditorProps, ref: any) {
    const { value, onChange } = props;
    const currentRef = ref || useRef();

    const uploadInstance = useUpload({});
    const { loading, file, data, cancel } = uploadInstance;

    const addImg = (file: File) => {
        const { upload } = uploadInstance;
        upload(file);
    }

    if (!loading && data) {
        currentRef.current.$img2Url(file?.name, `https://portal.static.levenx.com/${(data as any)?.key}`)
    }

    return (
        <div className="article-editor">
            <Editor
                ref={currentRef}
                value={value}
                preview={true}
                subfield={true}
                addImg={addImg}
                onChange={onChange} />
        </div>
    )
})
