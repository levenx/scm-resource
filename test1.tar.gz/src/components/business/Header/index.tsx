import React from 'react'
import Icon from '../../Icon';
import { Avatar, Image } from 'antd';
import './index.less';

export default function ConsoleHeader() {
    return (
        <div className="console-header">
            <Icon name="all" size={30} className="console-header-icon" />
            <Icon name="calendar" size={30} className="console-header-icon" />
            <Avatar className="console-header-icon" style={{ color: '#f56a00', backgroundColor: '#fde3cf' }}>U</Avatar>
        </div>
    )
}
