import React from 'react'
import { Avatar, Image } from 'antd'
import classnames from 'classnames';

interface RecordProps {
    type: 'left' | 'right';
    text: string;
}

export default function Record(props: RecordProps) {
    const { type, text } = props;
    return (
        <div className={classnames("chat-record", { 'chat-record--left': type === 'left', 'chat-record--right': type === 'right' })}>
            <Avatar
                className="avatar"
                size={54}
                src={<Image src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png" />}
            />
            <div className="chat-record--text">
                {text || 'No updates for now.'}
            </div>
        </div>
    )
}
