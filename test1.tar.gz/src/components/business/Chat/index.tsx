import React from 'react';
import List from './List';
import Window from './Window';
import './index.less';

export default function Chat() {
    //{ readyState, sendMessage, latestMessage, disconnect, connect } 
    // const { readyState, sendMessage, latestMessage, disconnect, connect } = useWebSocket(
    //     'ws://localhost:81',
    //     {

    //     }
    // );

    return (
        <div className="chat" onClick={() => {
            // sendMessage?.(JSON.stringify({ "event": "events", data: 11 }))
        }}>
            <List />
            <Window />
        </div>
    )
}
