import React from 'react';
import Search from '@/components/common/Search';
import { Avatar, Image } from 'antd';
import Icon from '@/components/Icon';

export default function List() {
    return (
        <section className="chat-list">
            <header className="chat-list__header">
                <span>Messages</span>
            </header>
            <ul className="chat-list__tab">
                <li className="chat-list__tab--item">Chats</li>
                <li className="chat-list__tab--item">Contacts</li>
                <li className="chat-list__tab--item">Contacts</li>
            </ul>
            <div className="chat-list__search">
                <Search />
            </div>
            <ul className="chat-list__content">
                {
                    [1, 1, 1, 1, 1, 1, 1, 1].map(item => {
                        return <li className="chat-list__content--item">
                            <div className="avatar">
                                <Avatar
                                    size={48}
                                    src={<Image src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png" />}
                                />
                            </div>
                            <div className="extra">
                                <div className="extra--nick">
                                    <span className="nick">Evginery Malyshev</span>
                                    <span className="time">
                                        10:25
                                        <Icon name="more" />
                                    </span>
                                </div>
                                <div className="extra--desc">
                                    Can you send me email  regarding the project...
                                </div>
                            </div>
                        </li>
                    })
                }
            </ul>
        </section>
    )
}
