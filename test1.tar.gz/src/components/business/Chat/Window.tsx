import React, { useState, useEffect } from 'react'
import { Avatar, Image } from 'antd'
import Icon from '@/components/Icon';
import Record from './Record';

export default function Window() {
    const [records, setRecords] = useState<any>([]);
    const [message, setMessage] = useState<string>('');

    useEffect(() => {
        setRecords(new Array(15).fill({ type: 'left', text: 'No updates for now.' }));
    }, [])

    const onSend = () => {
        const recordArr = records.concat({ type: 'right', text: message });
        setRecords(recordArr);
        setMessage('');
    }

    return (
        <section className="chat-window">
            <header className="chat-window__header">
                <div className="chat-window__header--left">
                    <Avatar
                        className="avatar"
                        size={54}
                        src={<Image src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png" />}
                    />
                    <div className="nick">
                        <p>Daria Mathew</p>
                        <p>online</p>
                    </div>
                </div>
                <div className="chat-window__header--right">
                    <Icon name="more" />
                </div>
            </header>
            <div className="chat-window__content">
                {
                    records.map((record: any) => {
                        return <Record type={record.type} text={record.text} />
                    })
                }
            </div>
            <div className="chat-window__send">
                <div className="chat-window__send--left">
                    <Icon name="smail" className="expression" />
                    <input className="message" placeholder="Write your message..." value={message} onChange={e => setMessage(e.target.value)} />
                </div>

                <div className="chat-window__send--right">
                    <Icon name="yuyin" className="message-func" />
                    <Icon name="attachent" className="message-func" />
                    <div className="message-send">
                        <Icon name="send" className="message-send--icon" onClick={onSend} />
                    </div>
                </div>
            </div>
        </section>
    )
}
