import React from 'react';
import { NavLink } from 'react-router-dom';
import { Menu } from '@/types';

import './index.less';


interface SpiderMenuProps {
    menus: Array<Menu>;
    className?: string;
    activeClassName?: string;
}

export default function SpiderMenu(props: SpiderMenuProps) {
    const { menus = [] } = props;
    return (
        <nav className="menu-nav">
            {
                menus.map(menu => {
                    return <NavLink
                        key={menu.path}
                        to={menu.path}
                        className="menu-nav--item"
                        activeClassName="menu-nav--active"
                        // 处理严格路由问题
                        exact={menu.path === '/'}
                    >
                        <span>{menu.title}</span>
                    </NavLink>
                })
            }
        </nav >
    )
}
