import React from 'react';
import { Button } from 'antd'
import './index.less';

interface ArticleTitleProps {
    value: string;
    onChange: (value: string) => void;
    extra?: React.ReactElement;
}

export default function ArticleTitle(props: ArticleTitleProps) {
    const { value, onChange, extra } = props;
    return (
        <div className="article-title">
            <input placeholder="请输入标题.." value={value} onChange={e => onChange(e?.target?.value as any)} autoFocus={true} />
            {
                extra
            }
        </div>
    )
}
