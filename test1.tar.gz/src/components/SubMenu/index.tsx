import React from 'react';
import { NavLink } from 'react-router-dom';

import './index.less';

const menus = [
    { path: '/setting', name: '网站设置' },
    { path: '/setting/region', name: '地区管理' },
    { path: '/setting/report', name: '数据报告' }
];

export default function SubMenu() {
    return (
        <div className="sub-menu">
            {
                menus.map(menu => {
                    return <NavLink
                        key={menu.path}
                        to={menu.path}
                        className="sub-menu__item"
                        activeClassName="sub-menu__item--active"
                        // 处理严格路由问题
                        exact={menu.path === '/setting'}
                    >{menu.name}</NavLink>
                })
            }
        </div>
    )
}
