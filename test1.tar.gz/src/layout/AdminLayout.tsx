import React, { Suspense } from 'react';
import { Layout, } from 'antd'
import { Loading } from '@/components';
import Logo from '../components/Logo';
import Menu from '../components/Menu';
import ConsoleHeader from '../components/business/Header';
import { renderRoutes } from 'react-router-config';
import './Admin.less';

const { Sider, Header, Content, Footer } = Layout;

export default function Admin({ route }: any) {
    return <Layout className="app">
        <Sider className="admin-menu" width="220">
            <Logo />
            <Menu />
            <div>
                <img src="https://cdn.jsdelivr.net/gh/levenx/picture@master/material/4c2fdf5e077643779676f932fdbacaba.png" style={{ width: '100%' }} />
            </div>
        </Sider>
        <Layout className="admin-content">
            <Header className="admin-content__head">
                <ConsoleHeader />
            </Header>
            <Suspense fallback={<Loading />}>
                <Content className="admin-content__main">
                    {renderRoutes(route.routes)}
                </Content>
            </Suspense>
            {/* <Footer>Footer</Footer> */}
        </Layout>
    </Layout>
}
