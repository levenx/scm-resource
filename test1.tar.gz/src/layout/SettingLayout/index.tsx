import React from 'react'
import { renderRoutes } from 'react-router-config';
import SubMenu from '@/components/SubMenu';
import './index.less';

export default function SettingLayout({ route }: any) {
    return (
        <div className="setting-wrap">
            <aside className="setting-subnav">
                <SubMenu />
            </aside>
            <div className="setting-content">
                {renderRoutes(route.routes)}
            </div>
        </div>
    )
}