import React, { Suspense } from 'react'
import ReactDOM from 'react-dom'
import { BrowserRouter } from 'react-router-dom';
import Loading from '@/components/common/Loading';
import { renderRoutes } from 'react-router-config';
import 'antd/dist/antd.css';
import "@arco-design/web-react/dist/css/arco.css";
import 'dumbooo/lib/index.less';
import './style/global.less';

import { routes } from './routes';


if (IS_PROD) {
  console.log(`%c Version: ${BUILD_TIME}`, 'font-size:14px;color:red;')
}

ReactDOM.render(
  <Suspense fallback={<Loading />}>
    <BrowserRouter>
      {renderRoutes(routes)}
    </BrowserRouter>
  </Suspense>
  ,
  document.getElementById('root')
)
