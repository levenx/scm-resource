/// <reference types="vite/client" />
declare const BUILD_TIME: string;
declare const IS_PROD: boolean;