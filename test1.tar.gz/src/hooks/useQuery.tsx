import React, { useMemo } from 'react';
import { useLocation } from 'react-router';

export default function useQuery() {
    const { search } = useLocation();
    const queryParam = useMemo(() => {
        const reg = /([^=&\s]+)[=\s]*([^=&\s]*)/g;
        const query: any = {};
        while (reg.exec(search.replace("?",""))) {
            query[RegExp.$1] = RegExp.$2;
        }
        return query;
    }, [search]);
    return {
        ...queryParam
    }
}
