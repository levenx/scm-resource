import React, { useState, useEffect, useRef } from 'react';
import { useToggle } from '@umijs/hooks';
import * as qiniujs from 'qiniu-js';
import { loadUploadToken } from '@/service/public';
import { useImageCrop } from '@/components/common/ImageCrop';

const STATIC_PATH = 'https://portal.static.levenx.com';

export default function useUpload(props: any = {}) {
    const { crop } = props;

    const [token, setToken] = useState((window as any).uploadToken);
    const [file, setFile] = useState<File | null>(null);
    const [data, setData] = useState<string | null>(null);
    const [error, setError] = useState<any>();
    const [process, setProcess] = useState<any>();

    const cancelRef = useRef(null) as any;

    const { state: loading, toggle: setLoading } = useToggle();

    const { showCrop } = useImageCrop();

    useEffect(() => {
        if (!(window as any).uploadToken) {
            loadUploadToken().then(res => {
                (window as any).uploadToken = res.data;
                setToken(res.data)
            })
        }
    }, []);

    const key = `${new Date().getFullYear()}${new Date().getMonth()}${new Date().getDate()}${Math.random().toString(36).slice(-8)}`;

    const observer = {
        next(res: any) {
            setProcess(res?.total);
        },
        error(err: any) {
            setError(err);
            cancelRef.current = null;
        },
        complete(res: any) {
            setData(`${STATIC_PATH}/${res.key}`);
            setLoading(false);
            cancelRef.current = null;
        }
    }

    const qiniuUpload = (file: File) => {
        const observable = qiniujs.upload(file, key, token);
        const subscription = observable.subscribe(observer);
        cancelRef.current = subscription.unsubscribe;
    }

    const upload = (file: File) => {
        setLoading(true);
        setFile(file);
        setData(null);
        if (crop) {
            showCrop(file).then((targetFile: any) => {
                qiniuUpload(targetFile);
            });
        } else {
            qiniuUpload(file);
        }
    }

    const clear = () => {
        setFile(null);
        setError(null);
        setData(null);
    }

    return {
        file,
        upload,
        clear,
        cancel: cancelRef.current,
        loading,
        data,
        error,
        process
    }
}