import React, { useState, useEffect, useRef } from 'react';
import { useToggle } from '@umijs/hooks';
import request from '@/service/request';

export const uploadMaterial = (file: File, { packetKey, onProgress }: { packetKey: string, onProgress?: (value: any) => void }) => {
    const form = new FormData();
    form.append('file', file);
    form.append('packetKey', packetKey);
    return request.post(`http://api.portal.fmlg1688.cn/admin/material/upload`,
        form,
        {
            onUploadProgress: onProgress
        });
}

export default function useUpload(props: any = {}) {
    const { crop } = props;

    const [file, setFile] = useState<File | null>(null);
    const [data, setData] = useState<string | null>(null);
    const [error, setError] = useState<any>();
    const [process, setProcess] = useState<any>();

    const cancelRef = useRef(null) as any;

    const { state: loading, toggle: setLoading } = useToggle();

    const qiniuUpload = (file: File) => {
        uploadMaterial(file, {
            packetKey: 'material', onProgress: (value) => {
                const { loaded, total } = value;
                setProcess({ percent: (loaded / total) * 100 });
            }
        }).then(res => {
            setData(res.data.url)
        })
    }

    const upload = (file: File) => {
        setLoading(true);
        setFile(file);
        setData(null);
        qiniuUpload(file);
    }

    const clear = () => {
        setFile(null);
        setError(null);
        setData(null);
    }

    return {
        file,
        upload,
        clear,
        cancel: cancelRef.current,
        loading,
        data,
        error,
        process
    }
}