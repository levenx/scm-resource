export default {

    baseURL: 'http://api.material.levenx.com',
    // baseURL: 'http://39.108.168.104:8812',
    // baseURL: 'http://localhost:8812',
    timeout: 5000

}