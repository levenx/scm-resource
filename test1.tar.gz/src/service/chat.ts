import request from './request';

interface CustomerMessageProps {
    userId: string;
    content: string;
}

export const senCustomerMessage = (params: CustomerMessageProps) => {
    return request.post("/chat/customer/send", params);
}

export const getChatList = () => {
    return request.get("/chat/list");
}
