import request from './request';

interface UploadParams {
    file: Blob;
    packetKey?: string;
    onProgress?: any;
}

interface MaterialParams {
    pn: number;
    ps: number;
    packet?: string | null;
    status?: number;
}

const baseURL = 'http://api.portal.fmlg1688.cn';

export const getMaterials = (params: MaterialParams) => {
    return request.get('/admin/material', { params, baseURL });
}

export const uploadMaterial = ({ file, packetKey, onProgress }: UploadParams) => {
    const form = new FormData();
    form.append('file', file);
    form.append('packetKey', packetKey || '');
    return request.post(`/admin/material/upload`,
        form,
        {
            onUploadProgress: onProgress,
            baseURL
        });
}