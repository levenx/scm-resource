import request from './request';
import { ResponseData } from './type.d';

export const loadAssetNews = (pn: number, ps: number) => {
    return request.get("/asset/console/news", { params: { pn, ps } });
}

export const loadAssetCases = (pn: number, ps: number) => {
    return request.get("/asset/console/cases", { params: { pn, ps } });
}

export const loadAssetGoods = (pn: number, ps: number) => {
    return request.get("/asset/console/products", { params: { pn, ps } });
}

export const loadAssetAds = (pn: number, ps: number) => {
    return request.get("/asset/console/ads", { params: { pn, ps } });
}

export const createAsset = (body: any) => {
    return request.post('/asset/console', body)
}

export const deleteAsset = (id: number, type: string) => {
    return request.delete(`/asset/console/${id}`, { params: { type } });
}

export const settingAsset = (body: any) => {
    return request.post('/asset/setting', body);
}


export const onlyAsset = (id: string, type: string) => {
    return request.get<ResponseData>(`/asset/console/${id}`, { params: { type } });
}