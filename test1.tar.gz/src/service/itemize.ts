import request from './request';

export const loadItemize = (pid: number | null, pn: number, ps: number) => {
    return request.get("/itemize/console", { params: { pid, pn, ps } });
}

export const createItemize = (body: any) => {
    return request.post('/itemize/console', body)
}

export const deleteItemize = (id: number) => {
    return request.delete(`/itemize/console/${id}`);
}

export const loadItemizeSelect = () => {
    return request.get('/itemize/select');
}