import request from './request';

export const createConfig = (body: any) => {
    return request.post("/config/console/setting", body);
}


export const loadConfig = (identify: string) => {
    return request.get(`/config/${identify}`);
}