import request, { IResponse } from '@/service/request';


export const getOnlyRegion = (id: number): Promise<IResponse<null>> => {
    return request.get(`/admin/region/${id}`);
}
