import request, { IPageResponse } from '@/service/request';

interface RegionField {
    id: number;
    deputy: string;
    fullName: string;
    status: number;
    title: string;
    weight: number;
    createdAt: string;
}

export const fetchRegions = (pn: number, ps: number): Promise<IPageResponse<RegionField[]>> => {
    return request.get("/admin/region/list", { params: { pn, ps } });
}