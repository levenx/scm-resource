import request, { IResponse } from '@/service/request';

interface CategoryField {
    pid: number | null;
    id: number;
    title: string;
    type: string;
    weight: string;
    createdAt: string;
}

interface CategoryParams {
    id: number;
    title: string;
    type: string;
}

export const fetchCategory = (pid: number | null, pn: number, ps: number): Promise<IResponse<CategoryField[]>> => {
    return request.get("/admin/category", { params: { pid, pn, ps } });
}


export const createCategory = (params: Omit<CategoryParams, 'id'>): Promise<IResponse<null>> => {
    return request.post("/admin/category", params);
}


export const updateCategory = (params: CategoryParams): Promise<IResponse<null>> => {
    return request.put("/admin/category", params);
}

