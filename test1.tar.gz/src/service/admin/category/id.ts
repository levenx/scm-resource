import request, { IResponse } from '@/service/request';


export const delCategory = (id: number): Promise<IResponse<null>> => {
    return request.delete(`/admin/category/${id}`);
}
