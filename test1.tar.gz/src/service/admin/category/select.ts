import request, { IResponse } from '@/service/request';

interface CategoryOption {
    label: string;
    value: number;
    children: Array<CategoryOption>;
}


export const getCategorySelect = (): Promise<IResponse<CategoryOption[]>> => {
    return request.get(`/admin/category/select`);
}
