import request, { IPageResponse, IResponse } from '@/service/request';

export interface NewsField {
    id: number;
    title: string;
    content: string;
    keywords: string;
    picture: string;
    status: number;
    watch: number;
    createdAt: string;
}

export const fetchOnlyNews = (id: number): Promise<IPageResponse<NewsField>> => {
    return request.get(`/admin/asset/news/${id}`);
}
