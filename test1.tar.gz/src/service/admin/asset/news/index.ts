import request, { IPageResponse, IResponse } from '@/service/request';

export interface NewsField {
    id: number;
    title: string;
    content: string;
    keywords: string;
    picture: string;
    status: number;
    watch: number;
    createdAt: string;
    updatedAt: string;
    time: string;
}

export const fetchAssetNews = (pn: number, ps: number): Promise<IPageResponse<NewsField>> => {
    return request.get("/admin/asset/news", { params: { pn, ps } });
}


export const createAssetNews = (body: any): Promise<IResponse<null>> => {
    return request.post('/admin/asset/news', body)
}

export const updateAssetNews = (body: any): Promise<IResponse<null>> => {
    return request.put('/admin/asset/news', body)
}