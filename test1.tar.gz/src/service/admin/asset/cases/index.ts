import request, { IPageResponse, IResponse } from '@/service/request';

export interface GoodsField {
    id: number;
    title: string;
    content: string;
    keywords: string;
    picture: string;
    status: number;
    watch: number;
    createdAt: string;
    updatedAt: string;
    time: string;
}

export const fetchAssetCases = (pn: number, ps: number): Promise<IPageResponse<GoodsField>> => {
    return request.get("/admin/asset/cases", { params: { pn, ps } });
}


export const createAssetCases = (body: any): Promise<IResponse<null>> => {
    return request.post('/admin/asset/cases', body)
}

export const updateAssetCases = (body: any): Promise<IResponse<null>> => {
    return request.put('/admin/asset/cases', body)
}