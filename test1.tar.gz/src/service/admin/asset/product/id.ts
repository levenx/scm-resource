import request, { IPageResponse, IResponse } from '@/service/request';

export interface GoodsField {
    id: number;
    title: string;
    content: string;
    keywords: string;
    picture: string;
    status: number;
    watch: number;
    createdAt: string;
}

export const fetchOnlyGoods = (id: number): Promise<IPageResponse<GoodsField>> => {
    return request.get(`/admin/asset/product/${id}`);
}
