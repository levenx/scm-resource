import request, { IPageResponse, IResponse } from '@/service/request';


interface Itemize {
    id: string;
    title: string;
}
export interface GoodsField {
    id: number;
    title: string;
    content: string;
    keywords: string;
    picture: string;
    status: number;
    watch: number;
    createdAt: string;
    updatedAt: string;
    time: string;
    itemizes: Array<Itemize>;
}

export const fetchAssetGoods = (pn: number, ps: number, categoryId: number): Promise<IPageResponse<GoodsField>> => {
    return request.get("/admin/asset/product", { params: { pn, ps, categoryId } });
}

export const createAssetGoods = (body: any): Promise<IResponse<null>> => {
    return request.post('/admin/asset/product', body)
}

export const updateAssetGoods = (body: any): Promise<IResponse<null>> => {
    return request.put('/admin/asset/product', body)
}