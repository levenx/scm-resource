import request, { IResponse } from '@/service/request';

export interface HomeBannerField {
    id?: number;
    image: string;
    url: string;
    title: string;
}

export interface ConfigParams {
    identify: string;
    content: string;
    resume?: string;
}

export const createConfig = (body: ConfigParams): Promise<IResponse<null>> => {
    return request.post("/config/console/setting", body);
}


export const getHomeBanner = (): Promise<IResponse<HomeBannerField[]>> => {
    return request.get(`/config/home_banner`);
}