import request from './request';

export const loadUploadToken = () => {
    return request.get("/public/upload/token");
}