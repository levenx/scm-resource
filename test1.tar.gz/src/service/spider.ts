import request from './request';

export const loadAreaData = (pn: number, ps: number) => {
    return request.get("/area/console/list", { params: { pn, ps } });
}

export const onlyAreaData = (id: number) => {
    return request.get(`/area/only/${id}`);
}

export const createAreaData = (body: any) => {
    return request.post("/area/console", body);
}