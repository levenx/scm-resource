import request from './request';
import { ResponseData } from './type.d';

export const loadReports = (pn: number, ps: number) => {
    return request.get("/report", { params: { pn, ps } });
}