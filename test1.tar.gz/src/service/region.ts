import request from './request';
import { ResponseData } from './type.d';

export const loadRegions = (pn: number, ps: number) => {
    return request.get("/region/console/list", { params: { pn, ps } });
}

export const createRegion = (body: any) => {
    return request.post('/region', body);
}

export const deleteRegion = (id: number) => {
    return request.delete(`/region/${id}`)
}

export const onlyRegion = (id: number) => {
    return request.get(`/region/only/${id}`)
}

export const settingRegion = (body: any) => {
    return request.post('/region/setting', body);
}